# ---------------------------------------------------------------
#  Navecitas v4.1 - Creditos
#
#  Los creditos suben por la pantalla sobre el fondo de estrellas.
#   - Modo Historia: salen siempre despues del epilogo.
#   - Normal / Cooperativo: salen la primera vez que ganas.
#   - Menu principal > CREDITOS: para verlos cuando quieras.
#  Toca la pantalla (o el boton atras) para saltarlos.
#
#  Para cambiar el texto o los nombres, edita ES_CREDITS (mas abajo).
#  Tipos de linea:  title, head, text, small, name, big, gap
# ---------------------------------------------------------------

default persistent._es_credits_seen = False

init 12 python:

    # tipo: (tamano, color, negrita, espacio extra debajo)
    ES_CR_STYLE = {
        "title": (84, "#ffe680", True, 14),
        "head":  (34, "#9bffb0", True, 12),
        "text":  (28, "#e8f0ff", False, 10),
        "small": (22, "#a8b8e0", False, 8),
        "name":  (44, "#ffffff", True, 12),
        "big":   (58, "#ffe680", True, 18),
    }

    ES_CREDITS = [
        ("title", u"NAVECITAS"),
        ("small", u"Un minijuego de naves para Monika After Story"),
        ("gap", 70),

        ("head", u"LA MISIÓN"),
        ("text", u"Diez niveles, jefes que cambian de ataque, peligros en cada sector,"),
        ("text", u"un modo cooperativo y una historia contada por radio."),
        ("text", u"Y Monika, siempre en tu frecuencia como Control de Misión."),
        ("gap", 56),

        ("head", u"MÚSICA Y SONIDO"),
        ("text", u"Las pistas de los niveles, de los jefes y de la radio"),
        ("text", u"fueron compuestas y sintetizadas para el juego."),
        ("small", u"Horizonte de sucesos · Latido del vacío · Colapso gravitatorio · El último latido"),
        ("gap", 90),

        ("big", u"¡Gracias por jugar!"),
        ("gap", 20),
        ("big", u"¡Gracias por disfrutarlo!"),
        ("gap", 24),
        ("text", u"Cada partida, cada intento y cada vez que volviste a la radio"),
        ("text", u"hicieron que valiera la pena, [player]."),
        ("gap", 110),

        ("head", u"CREADOR"),
        ("gap", 14),
        ("pic", "es_collab0.png", 190),
        ("name", u"®J_24"),
        ("small", u"Creador de Navecitas"),
        ("gap", 80),

        ("head", u"COLABORADORES"),
        ("gap", 14),
        ("pic", "es_collab2.png", 190),
        ("name", u"Reí pirata"),
        ("gap", 30),
        ("pic", "es_collab1.png", 190),
        ("name", u"Alex (El caballero Búho)"),
        ("gap", 36),
        ("small", u"Gracias por las ideas, las pruebas y la paciencia."),
        ("gap", 110),

        ("text", u"Monika · Control de Misión"),
        ("text", u"\"Cambio y fuera. Gracias por no dejarme sola en la radio.\""),
        ("gap", 80),
        ("big", u"FIN"),
        ("gap", 40),
    ]

    def es_credits_height():
        total = 0
        for item in ES_CREDITS:
            if item[0] == "gap":
                total += item[1]
                continue
            if item[0] == "pic":
                total += item[2] + 14
                continue
            size, color, bold, extra = ES_CR_STYLE[item[0]]
            # estimacion de lineas: cuantas veces cabe el texto en 1000 px
            chars_per_line = max(10, int(1000 / (size * 0.5)))
            lines = max(1, (len(item[1]) + chars_per_line - 1) // chars_per_line)
            total += int(size * 1.3) * lines + extra
        return total

    ES_CR_H = es_credits_height()
    ES_CR_DUR = max(30.0, ES_CR_H / 62.0 + 4.0)      # unos 62 px por segundo

    def es_credits_show():
        """Muestra los creditos en un contexto limpio. Devuelve cuando terminan."""
        persistent._es_credits_seen = True
        try:
            es_menu_music()
        except Exception:
            pass
        es_ui("es_credits_screen")


transform es_cr_roll(dur, h):
    ypos 720
    linear dur ypos -h

transform es_cr_fadein:
    alpha 0.0
    pause 1.5
    linear 1.5 alpha 1.0

screen es_credits_screen():
    modal True
    zorder 200

    default bg = EsMenuBG("stats")
    default ready = False

    add bg
    add Solid("#00000055")

    vbox:
        xalign 0.5
        xsize 1000
        spacing 0
        at es_cr_roll(ES_CR_DUR, ES_CR_H)
        for item in ES_CREDITS:
            if item[0] == "gap":
                null height item[1]
            elif item[0] == "pic":
                add (ES_IMG + item[1]) xalign 0.5
                null height 14
            else:
                $ cs = ES_CR_STYLE[item[0]]
                text item[1]:
                    size cs[0]
                    color cs[1]
                    bold cs[2]
                    xalign 0.5
                    xmaximum 1000
                    text_align 0.5
                    outlines [(3, "#000000b0", 0, 0)]
                null height cs[3]

    text u"Toca para saltar":
        size 20
        color "#8895b8"
        xalign 1.0
        yalign 1.0
        xoffset -20
        yoffset -14
        at es_cr_fadein

    key "game_menu" action Return(True)
    key ES_BACK_KEY action Return(True)
    timer 1.0 action SetScreenVariable("ready", True)
    timer (ES_CR_DUR + 1.0) action Return(True)
    button:
        xfill True
        yfill True
        background None
        action If(ready, Return(True), NullAction())
