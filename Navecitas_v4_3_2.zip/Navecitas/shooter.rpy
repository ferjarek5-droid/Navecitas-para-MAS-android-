# ---------------------------------------------------------------
#  Navecitas v4.0 - Minijuego de naves para MAS (decoracion de nivel: hazards.rpy)
#  8 niveles + 2 niveles bonus + modo infinito + practica + tienda
#  + modo Historia (story.rpy) + salto hiperespacial entre niveles.
#  Compatible con Ren'Py 7 (Python 2) y Ren'Py 8 (Python 3).
#
#  MUSICA PROPIA: pon en la carpeta audio/ archivos llamados
#  custom_stage.ogg, custom_stage2.ogg, custom_boss.ogg o
#  custom_boss2.ogg y custom_menu.ogg (tambien .mp3 / .opus) y se usaran en lugar
#  de la musica incluida. Si falta "2", usa la version sin numero.
# ---------------------------------------------------------------

init -1 python:
    renpy.music.register_channel("es_sfx", "sfx", False)
    renpy.music.register_channel("es_sfx2", "sfx", False)
    renpy.music.register_channel("es_sfx3", "sfx", False)
    renpy.music.register_channel("es_music", "music", True)
    renpy.music.register_channel("es_sfx4", "sfx", False)

init 10 python:
    import random
    import math
    try:
        import pygame_sdl2 as es_pygame
    except ImportError:
        import pygame as es_pygame

    # tecla "atras" de Android (si no existe, Esc)
    ES_BACK_KEY = "K_AC_BACK" if hasattr(es_pygame, "K_AC_BACK") else "K_ESCAPE"

    ES_W = 1280
    ES_H = 720
    ES_IMG = "Submods/Navecitas/images/"
    ES_SND = "Submods/Navecitas/audio/"

    # Limites para que nunca haya lag
    ES_MAX_BULLETS = 48
    ES_MAX_ENEMIES = 9
    ES_MAX_EBULLETS = 48
    ES_MAX_BOOMS = 8
    ES_MAX_POWERUPS = 4
    ES_STARS = 30
    # fondos: nebulosa (640x360 al doble, se repite en vertical) y un planeta por nivel
    ES_PLANET_SZ = [(190, 190), (170, 170), (210, 210), (160, 160),
                    (250, 250), (299, 190), (299, 190), (250, 250),
                    (250, 250), (250, 250)]   # tamano en pantalla (las imagenes son al doble)
    ES_NEB_SPD = 7.0       # px/s
    ES_PLANET_SPD = 11.0   # px/s

    # nombre, color de fondo, pesos de enemigos (basico, tirador, kamikaze, tanque,
    # dardo, francotirador, carguero)
    ES_STAGES = [
        (u"Órbita Terrestre",      "#070718", (10, 2, 0, 0, 0, 0, 0)),
        (u"Cinturón de Asteroides", "#0b0a1e", (8, 3, 3, 0, 2, 0, 0)),
        (u"Nebulosa Carmesí",      "#1a0710", (6, 3, 3, 2, 3, 0, 1)),
        (u"Base Enemiga",          "#0a1218", (5, 4, 3, 2, 3, 2, 2)),
        (u"Tormenta Solar",        "#1c1004", (5, 4, 4, 3, 3, 2, 2)),
        (u"Campo de Hielo",        "#06161c", (4, 4, 4, 3, 3, 3, 2)),
        (u"Núcleo Alienígena",     "#12081c", (3, 5, 4, 4, 3, 3, 3)),
        (u"Nave Nodriza",          "#1c0606", (3, 5, 5, 5, 3, 4, 3)),
        (u"Agujero Negro",         "#06031a", (2, 5, 5, 5, 4, 4, 4)),
        (u"Corazón del Vacío",     "#16030f", (2, 5, 5, 6, 4, 5, 5)),
    ]
    ES_NST = len(ES_STAGES)
    # tamano de cada tipo de enemigo (el 4 es la roca del nivel bonus) y puntos
    # 5-7: dardo (zigzag), francotirador y carguero (se divide al morir)
    ES_ESZ = [(60, 50), (60, 50), (60, 60), (90, 70), (56, 56), (56, 48), (64, 56), (88, 68)]
    ES_ESCORE = [10, 25, 15, 40, 5, 20, 30, 35]
    # posicion en los pesos de cada nivel -> tipo de enemigo (el 4 es la roca del bonus)
    ES_KINDMAP = [0, 1, 2, 3, 5, 6, 7]
    # ataques de cada jefe (se van alternando)
    ES_PATTERNS = [
        ["volley"],
        ["volley", "aimed"],
        ["rain", "volley"],
        ["aimed", "fan"],
        ["fan", "rain"],
        ["spiral", "volley"],
        ["spiral", "aimed", "rain"],
        ["spiral", "fan", "aimed", "rain"],
        ["spiral", "aimed", "fan", "rain"],
        ["fan", "spiral", "rain", "aimed", "volley"],
    ]
    # mini-jefes: aparecen a mitad de cada nivel (indice = nivel): nombre y ataques
    ES_MINI = [
        (u"Escolta Orbital",   ["volley", "aimed"]),
        (u"Centinela Pétreo",  ["volley", "walls"]),
        (u"Dron Carmesí",      ["fan", "zigzag"]),
        (u"Carguero Hostil",   ["aimed", "walls"]),
        (u"Escolta Solar",     ["rain", "zigzag", "aimed"]),
        (u"Centinela Glacial", ["fan", "walls", "aimed"]),
        (u"Dron Alienígena",   ["spiral", "walls", "zigzag"]),
        (u"Guardia Real",      ["spiral", "aimed", "walls", "zigzag"]),
        (u"Horizonte Roto",    ["spiral", "fan", "walls", "zigzag"]),
        (u"Latido del Vacío",  ["spiral", "aimed", "rain", "walls", "zigzag"]),
    ]
    # power-ups: 0 arma, 1 escudo, 2 vida, 3 bomba, 4 rapido, 5 x2,
    #            6 moneda (solo bonus), 7 iman, 8 drones, 9 laser, 10 tiempo lento
    ES_DROPS = ([0] * 26 + [1] * 16 + [2] * 7 + [3] * 14 + [4] * 12 + [5] * 12
                + [7] * 9 + [8] * 9 + [9] * 8 + [10] * 9)
    ES_RANK_BONUS = {"S": 500, "A": 300, "B": 150, "C": 0}

    # comentarios de Monika durante la partida
    ES_SAYS = {
        "start":    [u"¡Vamos, tú puedes!", u"¡A volar!", u"¡Yo te animo desde aquí!"],
        "hurt":     [u"¡Cuidado!", u"¡Auch! ¿Estás bien?", u"¡Tú puedes!", u"¡Esquiva con calma!"],
        "low":      [u"¡Última vida! Con calma...", u"¡Ánimo, aún no se acaba!",
                     u"Respira, tú puedes."],
        "boss":     [u"¡Ahí viene el jefe!", u"¡Concéntrate!", u"¡Fíjate en sus patrones!"],
        "mini":     [u"¡Un mini-jefe! ¡Cuidado!", u"¡Viene un guardián!", u"¡Es una escolta, concéntrate!"],
        "phase2":   [u"¡Se está enfureciendo!", u"¡Cambió de patrón!", u"¡Ahora va en serio!"],
        "clear":    [u"¡Lo hiciste!", u"¡Eso fue genial!", u"¡Un jefe menos!"],
        "rankS":    [u"¡Rango S! ¡Increíble!", u"¡Perfecto! ¡Rango S!"],
        "combo":    [u"¡Qué combo!", u"¡No pares!", u"¡Sigue así!"],
        "life":     [u"¡Una vida extra!", u"¡Qué alivio!"],
        "bomb":     [u"¡Boom!", u"¡Eso los despejó!", u"¡Bomba!"],
        "autobomb": [u"¡Bomba de emergencia!"],
        "laser":    [u"¡Qué rayo!", u"¡Pew pew!"],
        "drones":   [u"¡Ahora somos más!"],
        "bonus":    [u"¡Nivel bonus! ¡A recoger monedas!"],
        "graze":    [u"¡Qué reflejos!", u"¡Por un pelo!", u"¡Eso estuvo cerca!"],
        "m_intro":  [u"¡Juntos podemos!", u"¡Yo cubro tu espalda!", u"¡A volar juntos!"],
        "m_hit":    [u"¡Ay! Estoy bien, sigue tú.", u"¡Me dieron! Dame un segundo."],
        "m_save":   [u"¡Te cubro!", u"¡Yo me encargo de este golpe!", u"¡Cuidado, yo te protejo!"],
    }
    ES_STATUS_NAMES = [u"Rápido", u"x2", u"Imán", u"Drones", u"Láser", u"Lento"]
    # texto flotante al recoger cada power-up (mismo orden que ES_DROPS)
    ES_PU_NAMES = [u"¡Arma!", u"¡Escudo!", u"+1 vida", u"+1 bomba", u"¡Rápido!",
                   u"¡x2!", u"+1", u"¡Imán!", u"¡Drones!", u"¡Láser!", u"¡Lento!"]
    ES_PU_COL = ["#ffd24d", "#6fd3ff", "#ff7aa8", "#ff6a5a", "#ffe680",
                 "#ffb347", "#ffe066", "#c79bff", "#9bffb0", "#9fe8ff", "#b0b8ff"]

    # ------------------------------------------------------------
    #  Efectos visuales (v3.8). Nivel en Ajustes: 0 minimos (sin
    #  destellos ni temblor), 1 reducidos, 2 completos.
    # ------------------------------------------------------------
    ES_FX_MAX = (0, 40, 90)                # tope de particulas por nivel
    ES_ALPHA_LV = ["ff", "c0", "80", "40"]  # opacidad de las particulas al envejecer
    ES_RING_N = 8                           # anillos: 0 blanco 1 oro 2 cian 3 rojo 4 verde 5 violeta 6 naranja 7 rosa
    # color de la estela del motor segun la nave (indice de skin)
    ES_SKIN_TRAIL = ["#50c0f0", "#f050a0", "#70f050", "#f0e050", "#cfd6ff",
                     "#50f0f0", "#f03050", "#f050e0", "#ffd991"]
    ES_COSMIC = ["#ffd991", "#6fd3ff", "#c79bff"]
    # anillo de cada power-up (mismo orden que ES_DROPS)
    ES_PU_RING = [1, 2, 7, 3, 1, 6, 1, 5, 4, 2, 5]
    ES_EN_NAMES = ["enemy1", "enemy2", "enemy3", "enemy4", "rock", "enemy5", "enemy6", "enemy7"]
    # jefes: nombre y colores de sus explosiones (anillo, chispas) por nivel
    ES_BOSS_NAMES = [u"Comandante Orbital", u"Titán Rocoso", u"Ojo Carmesí", u"Señor de la Base",
                     u"Coloso Solar", u"Reina de Hielo", u"Cerebro Alienígena", u"Nave Nodriza",
                     u"Devorador de Luz", u"Corazón del Vacío"]
    ES_BOSS_FX = [(5, ["#c79bff", "#9fb0ff", "#ffffff"]), (4, ["#9bffb0", "#5fd06f", "#ffffff"]),
                  (5, ["#d89bff", "#ff7aa8", "#ffffff"]), (6, ["#ffb347", "#ffe680", "#ffffff"]),
                  (2, ["#6fd3ff", "#9fe8ff", "#ffffff"]), (2, ["#9fe8ff", "#ffffff", "#b0b8ff"]),
                  (3, ["#ff7a8a", "#ff4466", "#ffffff"]), (1, ["#ffe066", "#ffb347", "#ffffff"]),
                  (4, ["#9bffb0", "#c79bff", "#ffffff"]), (7, ["#ff4fa0", "#ff9ad0", "#ffffff"])]
    # brillo de las balas del jugador segun el nivel de arma
    ES_BUL_GLOW = {1: "#6fd3ff", 2: "#ffd24d", 3: "#ff7aa8"}
    ES_SPARK_HIT = ["#ffffff", "#ffe680"]
    ES_SPARK_KILL = ["#ffb347", "#ffe680", "#ff7a5a", "#ffffff"]
    ES_SPARK_ROCK = ["#b8a89a", "#8a7c70", "#d8c8b8"]
    ES_CONFETTI = ["#ffe066", "#ffffff", "#ffb347", "#9bffb0", "#6fd3ff", "#ff7aa8"]
    # particulas de ambiente por nivel: (tipo, color, tamano)
    ES_AMB = {2: ("dust", "#ff6a7a", 3), 4: ("ember", "#ffb347", 3),
              5: ("snow", "#ffffff", 3), 6: ("spore", "#9bffb0", 3),
              8: ("void", "#c79bff", 3), 9: ("void", "#ff4fa0", 3)}
    # mezcla del parpadeo blanco al recibir dano (45% imagen + 55% blanco)
    ES_FLASH_M = im.matrix(0.45, 0, 0, 0, 0.55,
                           0, 0.45, 0, 0, 0.55,
                           0, 0, 0.45, 0, 0.55,
                           0, 0, 0, 1, 0)

    def es_overlap(ax, ay, aw, ah, bx, by, bw, bh):
        return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah

    def es_track(name):
        """Musica personalizada si existe; si no, la incluida."""
        names = [name]
        if name[-1].isdigit():
            names.append(name.rstrip("0123456789"))
        for n in names:
            for ext in (".ogg", ".mp3", ".opus"):
                p = ES_SND + "custom_" + n + ext
                if renpy.loadable(p):
                    return p
        return ES_SND + name + ".ogg"


    class EncodersShooter(renpy.Displayable):

        # salto hiperespacial entre niveles (segundos): carga, impulso,
        # fundido a negro, pantalla negra con el titulo y llegada al nivel nuevo
        WP_A = 0.75
        WP_B = 1.8
        WP_C = 2.4
        WP_D = 3.6
        WP_ARR = 1.6

        def __init__(self, mode="normal", diff="normal", pstage=1, **kwargs):
            super(EncodersShooter, self).__init__(**kwargs)
            self.mode = mode
            self.endless = (mode == "endless")
            self.practice = (mode == "practice")
            self.start_n = max(1, min(ES_NST, int(pstage))) if self.practice else 1
            self.nst = 8 if mode == "story" else ES_NST     # la historia sigue siendo de 8 niveles
            self.quitting = False
            self.q_st0 = None
            self.relative = persistent._es_relative
            # tope de cuadros: 0 = ahorro (30), 1 = equilibrado (60), 2 = sin tope
            self.rdt = (0.0325, 0.0165, 0.0)[max(0, min(2, persistent._es_perf))]
            self.diff = diff if diff in ES_DIFFS else "normal"
            self.D = dict(ES_DIFFS[self.diff])
            self.coop = (mode == "coop")
            if self.coop:
                # con Monika de ayuda los enemigos aparecen mas y los jefes aguantan mas
                self.D["spawn"] *= 0.85
                self.D["boss"] *= 1.3

            # ajustes del jugador (se leen una vez por partida)
            self.opt_off = persistent._es_offset
            self.lefty = persistent._es_lefty
            self.dtap = persistent._es_dtap
            self.autobomb = persistent._es_autobomb
            self.vibrate = persistent._es_vibrate
            self.comments = persistent._es_comments
            # nivel de efectos visuales (el modo "Ahorro" de rendimiento los limita)
            self.fx = max(0, min(2, persistent._es_fx))
            if persistent._es_perf == 0 and self.fx > 1:
                self.fx = 1
            self.fx_max = ES_FX_MAX[self.fx]
            sk = persistent._es_skin
            if sk < 0 or sk >= len(ES_SKINS) or not es_skin_unlocked(sk):
                sk = 0
            sfx = "" if sk == 0 else "_%d" % sk

            # habilidad de la nave elegida
            self.pick_pad = 12 if sk == 1 else 0        # Rosa: recoge de mas lejos
            self.drop_mult = 1.5 if sk == 2 else 1.0    # Esmeralda: mas power-ups
            self.sk_sc = 12 if sk == 3 else 10          # Dorada: +20% de puntos
            self.inv_hit = 2.4 if sk == 4 else 1.6      # Fantasma: mas invulnerable
            self.sk = sk
            self.shield_mult = 1.5 if sk == 5 else 1.0  # Celeste: escudos mas largos
            self.crit = 0.2 if sk == 6 else 0.0         # Carmesi: 20% de balas con doble dano
            self.sk_life = 1 if sk == 8 else 0          # Cosmica: una vida extra

            # mejoras compradas en la tienda
            self.up_bomb = es_upg("bomb")
            self.up_shield = es_upg("shield")
            self.up_life = es_upg("life")
            self.up_weapon = es_upg("weapon")
            self.pu_dur = 1.0 + 0.15 * es_upg("pu")
            self.drop_mult *= 1.0 + 0.2 * es_upg("loot")          # Radar de botin
            self.up_magnet = es_upg("magnet")                     # Iman inicial
            self.combo_len = 3.5 + 0.8 * es_upg("combo")          # Combo duradero
            self.bomb_pow = 0.1 + 0.04 * es_upg("bombpow")        # Bomba potente
            self.graze_pts = 5 + 5 * es_upg("graze")              # Roce premiado

            L = renpy.displayable
            I = lambda n: L(ES_IMG + "es_" + n + ".png")
            self.i_player = I("player" + sfx)
            self.i_bullet = I("bullet" + sfx)
            self.i_en = [I("enemy1"), I("enemy2"), I("enemy3"), I("enemy4"), I("rock"),
                         I("enemy5"), I("enemy6"), I("enemy7")]
            self.i_ebullet = I("ebullet")
            self.i_star = [I("star1"), I("star2")]
            self.i_heart = I("heart")
            self.i_boom = [I("boom%d" % i) for i in range(4)]
            self.i_pu = [I("powerup_w"), I("powerup_s"), I("powerup_h"),
                         I("powerup_b"), I("powerup_r"), I("powerup_x"),
                         I("coin"), I("powerup_m"), I("powerup_d"),
                         I("powerup_l"), I("powerup_t")]
            self.i_boss = [I("boss%d" % i) for i in range(ES_NST)]  # 160x112
            self.i_mini = [I("mini%d" % i) for i in range(ES_NST)]  # 128x92
            self.i_shield = I("shield")
            self.i_bombbtn = I("bombbtn")    # 100x100
            self.i_drone = I("drone")
            self.i_monika = I("monika")      # 56x56
            self.i_neb = [Transform(I("neb%d" % i), zoom=2.0) for i in range(ES_NST)]
            self.i_planet = [Transform(I("planet%d" % i), zoom=0.5) for i in range(ES_NST)]
            self.i_ring = [I("ring_%d" % i) for i in range(ES_RING_N)]
            self.i_vig = [Transform(I("vig_%d" % i), zoom=4.0) for i in range(3)]   # 320x180 -> pantalla
            self.i_bolt = [I("bolt%d" % i) for i in range(3)]
            self.bolt_fl = Solid("#ffffff22")
            self.tele_a = Solid("#ff4466a0", xysize=(8, 54))
            self.tele_b = Solid("#ffffffd0", xysize=(8, 8))
            self.pimg_cache = {}
            self.tf_cache = {}
            self.flash_cache = {}
            self.vig_cache = {}
            self.bgs = [Solid(s[1]) for s in ES_STAGES]
            self.flash_s = [Solid("#ffffff40"), Solid("#ffffff80"), Solid("#ffffffb8")]
            self.laser_o = Solid("#5fd0ff55", xysize=(28, ES_H))
            self.laser_i = Solid("#e8fbffcc", xysize=(10, ES_H))
            self.bar_bg = Solid("#000000aa", xysize=(408, 16))
            self.bars = [None] + [Solid("#ff4455", xysize=(20 * k, 10))
                                  for k in range(1, 21)]
            T = lambda s, sz, c: Text(s, size=sz, color=c, outlines=[(3, "#000000", 0, 0)])
            self.T = T
            self.t_warn = T(u"¡ADVERTENCIA!", 80, "#ff4455")
            self.t_clear = T(u"¡NIVEL COMPLETADO!", 70, "#66ff99")
            self.t_pause = T(u"PAUSA", 90, "#ffffff")
            self.t_resume = T(u"Toca para continuar", 36, "#dddddd")
            self.t_ph2 = T(u"¡FASE 2!", 80, "#ffb347")
            self.t_count = [None] + [T(u"%d" % i, 150, "#ffffff") for i in (1, 2, 3)]
            self.t_ready = T(u"¡Prepárate!", 40, "#dddddd")
            self.t_msave_on = Text(u"Monika: cubriéndote", size=24, color="#9bffb0",
                                   outlines=[(2, "#000000", 0, 0)])
            self.t_msave_off = Text(u"Monika: recargando", size=24, color="#aaaaaa",
                                    outlines=[(2, "#000000", 0, 0)])
            self.t_mstun = Text(u"¡Ay!", size=24, color="#ffffff",
                                outlines=[(2, "#000000", 0, 0)])
            self.float_cache = {}
            # animacion de salto entre niveles
            self.black_s = [Solid("#000000%02x" % int(255 * i / 10.0)) for i in range(11)]
            self.flame_o = [Solid("#ff9a2e", xysize=(14, h)) for h in (18, 34, 52, 74)]
            self.flame_i = [Solid("#fff3b0", xysize=(6, int(h * 0.6))) for h in (18, 34, 52, 74)]
            self.t_jump = T(u"¡SALTO HIPERESPACIAL!", 60, "#9fe8ff")
            self.streak_cache = {}
            self.bar_cache = {}
            self.part_cache = {}
            self.bank_cache = {}
            self.eng_o = [Solid("#ff9a2e", xysize=(10, h)) for h in (8, 14, 22, 32)]
            self.eng_i = [Solid("#fff3b0", xysize=(4, int(h * 0.6))) for h in (8, 14, 22, 32)]
            self.core_o = Solid("#ff4466", xysize=(10, 10))
            self.core_i = Solid("#ffffff", xysize=(6, 6))
            self.say_cache = {}
            self.all_images = ([self.i_player, self.i_bullet, self.i_ebullet,
                                self.i_heart, self.i_shield, self.i_bombbtn,
                                self.i_drone, self.i_monika]
                               + self.i_en + self.i_star + self.i_boom
                               + self.i_pu + self.i_boss + self.i_mini + self.i_neb + self.i_planet
                               + self.i_ring + self.i_vig + self.i_bolt)
            es_hz_init(self)      # decoracion de nivel (hazards.rpy)
            self.reset()

        # ---------- estado ----------
        def reset(self):
            self.px = ES_W / 2.0
            self.py = ES_H - 120.0
            self.tx = self.px
            self.ty = self.py
            self.bullets = []    # [x, y, vx]
            self.enemies = []    # [basex, y, speed, phase, kind, hp, shoot_t, x, (espera)]
            self.pending = []    # enemigos nuevos (hijos del carguero)
            self.ebullets = []   # [x, y, vx]
            self.booms = []      # [x, y, t]
            self.powerups = []   # [x, y, tipo]
            self.boss = None     # [x, y, hp_total, maxhp, dir, shoot_t]  (hp_total = suma de las piezas)
            self.bparts = []     # piezas del jefe: [x, y, ancho, alto, vida, vida_max, exterior]
            self.fx_psmoke_t = 0.0
            self.bank = 0.0      # inclinacion de la nave segun su movimiento lateral (-1..1)
            self.bank_px = self.px
            self.mbank = 0.0
            self.bank_mx = ES_W / 2.0 + 110
            self.eng = 0.0       # intensidad del motor (0..1) segun el movimiento
            self.eng_py = self.py
            self.ghosts = []     # postimagenes de la nave al moverse rapido: [x, y, inclinacion, edad]
            self.ghost_t = 0.0
            self.sh_hit = 0.0    # onda del escudo al absorber un golpe
            self.brec = [0.0, 0.0]   # empujon del jefe al perder una pieza
            self.far_rocks = []  # asteroides lejanos: [x, y, vy, vx, zoom]
            self.fr_t = 3.0
            self.dust = [[random.uniform(0, ES_W), random.uniform(0, ES_H),
                          random.uniform(300, 520)] for _i in range(36)]
            self.rank_big = None
            self.bp_key = None
            self.bp_txt = None
            self.volley = 0
            self.spiral = 0.0
            self.stars = []     # capa lejana (lenta) y cercana (rapida)
            for i in range(ES_STARS):
                typ = random.randint(0, 1)
                spd = random.uniform(40, 100) if typ == 0 else random.uniform(140, 260)
                self.stars.append([random.uniform(0, ES_W), random.uniform(0, ES_H),
                                   spd, typ])
            self.score = 0
            self.lives = self.D["lives"] + self.up_life + self.sk_life
            self.bombs = 1 + self.up_bomb
            self.wl = 2 if self.up_weapon else 1
            for n in ("shield", "rapid", "x2", "magnet", "drones", "laser", "slow",
                      "flash", "inv", "fire_t", "over_t", "elapsed", "combo_t",
                      "dang", "dr_t", "laser_t", "ph2_t", "say_t", "say_cd",
                      "coin_t", "shake", "resume_t", "ach_t",
                      "arrive_t", "ship_dy", "wp_black", "mini_t"):
                setattr(self, n, 0.0)
            self.star_mul = 1.0
            self.wp_lines = []
            self.wp_title = None
            self.wp_tf = {}
            self.warp_kind = None
            self.warp_n = 1
            self.warp_story = False
            self.warp_story_done = False
            self.warp_launched = False
            self.spawn_t = 1.0
            self.over = False
            self.leaving = False     # fundido a negro al salir de la derrota
            self.leave_t = 0.0
            self.fail_who = u""
            self.victory = False
            self.paused = False
            self.auto_paused = False
            self.confirm = False
            self.last_st = None
            self.last_tap = -9.0
            self.tap_x = 0
            self.tap_y = 0
            self.down = False
            self.anc_x = 0
            self.anc_y = 0
            self.anc_tx = self.tx
            self.anc_ty = self.ty
            self.floats = []     # [x, y, t, Text]
            self.toasts = []     # [Text, t]
            self.toasted = set()
            self.grazes = 0
            self.shoot_n = 0
            self.sfx_i = 0
            # companera Monika (modo cooperativo)
            self.mx = ES_W / 2.0 + 110
            self.my = ES_H - 100.0
            self.m_side = 1
            self.m_stun = 0.0
            self.m_inv = 0.0
            self.m_fire = 0.5
            self.m_save = 1 if self.coop else 0
            self.neb_y = 0.0
            self.planet = None     # [x, y] del planeta de fondo
            # contadores de la partida
            self.combo = 0
            self.maxcombo = 0
            self.kills = 0
            self.bosses = 0
            self.minis = 0
            self.mini_txt = None
            self.hits = 0
            self.lives_lost = 0
            self.death_log = []   # [(nivel 1-10, categoria, detalle)] una por vida perdida
            self.bombs_used = 0
            self.pu_count = 0
            self.pu_types = set()
            self.coins = 0
            self.ranks = []
            self.ph2 = False
            self.rank_txt = None
            self.say_txt = None
            self.hud_key = None
            self.hud_txt = None
            self.st_key = None
            self.st_txt = None
            self.cb_key = None
            self.cb_txt = None
            self.bomb_key = None
            self.bomb_txt = None
            self.over_txt = None
            # efectos visuales
            self.parts = []       # particulas delante: [x, y, vx, vy, t, vida, color, gravedad, tam]
            self.parts_b = []     # particulas detras de la nave (estela, humo)
            self.rings = []       # anillos: [x, y, t, vida, zoom_max, indice]
            self.amb = []         # ambiente: [x, y, vx, vy, fase, tipo, color, tam, nivel]
            self.shots = []       # ataques con aviso: [segundos, balas, marcas_x]
            self.hflash = {}      # enemigos con parpadeo blanco: id -> segundos
            self.boss_flash = 0.0
            self.hitstop = 0.0
            self.slowmo = 0.0
            self.vig_hurt = 0.0
            self.vig_ph2 = 0.0
            self.hb_t = 0.0
            self.hb_pulse = 0.0
            self.fx_trail_t = 0.0
            self.fx_smoke_t = 0.0
            self.fx_amb_t = 0.0
            self.bolt = None
            self.bolt_t = 3.0
            self.chain = None
            self.combo_tier = 0
            self.rank_pop = False
            self.rank_ltr = "C"
            self.cu_cache = {}
            self.start_stage(self.start_n, True)

        def start_stage(self, n, first=False):
            self.stage = n
            self.si = (n - 1) % ES_NST          # indice de fondo/jefe/ataques
            self.dsc = min(n, 16)               # escala de dificultad
            self.phase = "intro"
            self.phase_t = 0.0
            self.stage_t = 0.0
            self.stage_hits = 0
            self.stage_spawned = 0
            self.stage_killed = 0
            self.ph2 = False
            self.mini_done = False
            self.amb = []
            # planeta de fondo de este nivel (baja muy despacio)
            self.planet = [random.uniform(180, ES_W - 180), random.uniform(-40, 200)]
            name = ES_STAGES[self.si][0]
            self.banner = [
                self.T(u"NIVEL %d" % n, 80, "#ffffff"),
                Text(name, size=42, color="#ffe680", outlines=[(2, "#000000", 0, 0)]),
            ]
            if self.up_shield:
                self.shield = max(self.shield, 4.0 * self.up_shield)
            if self.up_magnet:
                self.magnet = max(self.magnet, 5.0 * self.up_magnet)
            es_hz_start(self)
            if first:
                self.say("m_intro" if self.coop else "start", True)
                if n > 1:
                    self.set_music(self.stage_track(n))
            else:
                self.set_music(self.stage_track(n))

        def start_bonus(self):
            self.phase = "bonus"
            self.phase_t = 0.0
            self.spawn_t = 0.5
            self.coin_t = 0.8
            self.banner = [
                self.T(u"NIVEL BONUS", 80, "#ffe066"),
                Text(u"¡Esquiva las rocas y atrapa monedas!", size=38, color="#ffffff",
                     outlines=[(2, "#000000", 0, 0)]),
            ]
            self.say("bonus", True)

        def sfx(self, name):
            # el disparo usa su propio canal (y suena cada 3 tiros) para no
            # cortar explosiones ni recompensas; el resto rota entre 2 canales
            if name == "shoot":
                self.shoot_n += 1
                if self.shoot_n % 3 != 1:
                    return
                ch = "es_sfx3"
            else:
                self.sfx_i = 1 - self.sfx_i
                ch = "es_sfx2" if self.sfx_i else "es_sfx"
            renpy.music.play(ES_SND + name + ".ogg", channel=ch)

        def buzz(self, t):
            if self.vibrate:
                try:
                    renpy.vibrate(t)
                except Exception:
                    pass

        def stage_track(self, n):
            si = (n - 1) % ES_NST
            if si == 8:
                return "stage3"
            if si == 9:
                return "stage4"
            return "stage" if n % 2 else "stage2"

        def boss_track(self):
            if self.si == 8:
                return "boss3"
            if self.si == 9:
                return "boss4"
            return "boss" if self.si < 4 else "boss2"

        def set_music(self, name):
            renpy.music.play(es_track(name), channel="es_music", loop=True,
                             fadeout=0.4, fadein=0.4)

        def say(self, key, force=False):
            if not self.comments:
                return
            if self.say_cd > 0 and not force:
                return
            txt = u"Monika: " + random.choice(ES_SAYS[key])
            t = self.say_cache.get(txt)
            if t is None:
                t = Text(txt, size=30, color="#9bffb0", outlines=[(2, "#000000", 0, 0)])
                self.say_cache[txt] = t
            self.say_txt = t
            self.say_t = 2.8
            self.say_cd = 5.0

        def add_float(self, x, y, s, color):
            if len(self.floats) >= 8:
                return
            key = (s, color)
            t = self.float_cache.get(key)
            if t is None:
                t = Text(s, size=26, color=color, outlines=[(2, "#000000", 0, 0)])
                self.float_cache[key] = t
            self.floats.append([x, y, 0.0, t])

        def check_live(self):
            """Avisa en pantalla cuando se cumple un logro durante la partida."""
            if self.practice:
                return
            cand = (("combo30", self.maxcombo >= 30),
                    ("score5000", self.score >= 5000),
                    ("coins15", self.coins >= 15),
                    ("collector", len(self.pu_types) >= 8),
                    ("graze100", self.grazes >= 100))
            for (i, ok) in cand:
                if ok and i not in self.toasted and not es_has_ach(i):
                    self.toasted.add(i)
                    self.toasts.append([self.T(u"¡Logro: %s!" % ES_ACH_NAME[i], 34, "#ffe066"), 3.2])
                    self.spark(ES_W / 2.0, 190, 22, ES_CONFETTI, spd=320, life=1.1, size=5, grav=220)

        def add_boom(self, x, y):
            if len(self.booms) < ES_MAX_BOOMS:
                self.booms.append([x, y, 0.0])

        def combo_mult(self):
            c = self.combo
            if c < 5:
                return 10
            if c < 10:
                return 15
            if c < 20:
                return 20
            return 30

        def add_score(self, n, combo=True):
            m = self.combo_mult() if combo else 10
            x2 = 2 if self.x2 > 0 else 1
            self.score += n * x2 * m * self.D["score"] * self.sk_sc // 1000

        def toggle_pause(self):
            if self.over:
                return
            self.paused = not self.paused
            self.auto_paused = False
            renpy.music.set_pause(self.paused, channel="es_music")
            if not self.paused:
                self.last_st = None
                self.resume_t = 2.4     # cuenta atras 3-2-1 antes de seguir
            renpy.redraw(self, 0)

        def ask_quit(self):
            if self.over:
                return
            self.confirm = True
            if not self.paused:
                self.toggle_pause()

        def cancel_quit(self):
            self.confirm = False
            if self.paused:
                self.toggle_pause()

        def back_key(self):
            """Boton 'atras' de Android / Esc: abre o cierra el cuadro de salir."""
            if self.over:
                return
            if self.confirm:
                self.cancel_quit()
            else:
                self.ask_quit()

        def do_quit(self):
            """Salir: fundido a negro (lo dibuja render) y luego finish_quit."""
            self.confirm = False
            self.quitting = True
            self.q_st0 = None
            try:
                renpy.music.set_pause(False, channel="es_music")
                renpy.music.stop(channel="es_music", fadeout=0.9)
                renpy.music.play(ES_SND + "warp.ogg", channel="es_sfx")
            except Exception:
                pass
            renpy.redraw(self, 0)

        def finish_quit(self):
            return self.summary(True)

        def summary(self, quit=False):
            return {
                "score": self.score, "stage": self.stage, "win": self.victory,
                "quit": quit, "mode": self.mode, "diff": self.diff,
                "hits": self.hits, "lives_lost": self.lives_lost,
                "bombs_used": self.bombs_used, "maxcombo": self.maxcombo,
                "kills": self.kills, "bosses": self.bosses,
                "time": self.elapsed, "pu": self.pu_count, "coins": self.coins,
                "ranks": list(self.ranks), "types": len(self.pu_types),
                "grazes": self.grazes, "skin": self.sk, "minis": self.minis,
                "fail_who": self.fail_who,
                "deaths_log": list(self.death_log),
            }

        # ---------- efectos visuales ----------
        def sfx4(self, name):
            renpy.music.play(ES_SND + name + ".ogg", channel="es_sfx4")

        def boom_name(self):
            c = self.combo
            return "boom" if c < 5 else ("boom_1" if c < 10 else ("boom_2" if c < 20 else "boom_3"))

        def tier_of(self, c):
            return 0 if c < 5 else (1 if c < 10 else (2 if c < 20 else 3))

        def spark(self, x, y, n, colors, spd=170.0, life=0.45, size=4, grav=0.0, back=False):
            """Chispas radiales. Respeta el tope de particulas del nivel de efectos."""
            if self.fx <= 0:
                return
            if self.fx == 1:
                n = (n + 1) // 2
            room = self.fx_max - len(self.parts) - len(self.parts_b)
            if room <= 0:
                return
            n = min(n, room)
            if not isinstance(colors, (list, tuple)):
                colors = [colors]
            P = self.parts_b if back else self.parts
            for i in range(n):
                a = random.uniform(0.0, 6.2832)
                v = random.uniform(0.35, 1.0) * spd
                P.append([x + random.uniform(-3, 3), y + random.uniform(-3, 3),
                          math.cos(a) * v, math.sin(a) * v, 0.0,
                          life * random.uniform(0.7, 1.2), random.choice(colors), grav, size])

        def debris(self, x, y, n, cols=("#8a8a99", "#5a5a66", "#b8b8c8"), spd=260,
                   grav=520.0, size=5, life=0.9):
            """Escombros que saltan hacia arriba y caen."""
            if self.fx <= 0:
                return
            if self.fx == 1:
                n = (n + 1) // 2
            n = min(n, self.fx_max - len(self.parts) - len(self.parts_b))
            for i in range(n):
                a = random.uniform(3.1416, 6.2832)
                v = random.uniform(0.3, 1.0) * spd
                self.parts.append([x + random.uniform(-6, 6), y + random.uniform(-6, 6),
                                   math.cos(a) * v, math.sin(a) * v, 0.0,
                                   life * random.uniform(0.7, 1.2), random.choice(cols), grav,
                                   random.choice((size - 1, size, size + 2))])

        def big_boom(self, x, y, si=None, power=1.0):
            """Explosion grande con los colores del jefe: onda, anillo, chispas y escombros."""
            ri, cols = ES_BOSS_FX[(self.si if si is None else si) % len(ES_BOSS_FX)]
            self.ring(x, y, 0, 3.4 * power, 0.5)
            self.ring(x, y, ri, 2.2 * power, 0.65)
            self.spark(x, y, int(18 * power), cols, spd=380, life=0.8, size=5, grav=120)
            self.debris(x, y, int(10 * power), spd=300)

        def trail(self, x, y, col):
            if len(self.parts) + len(self.parts_b) >= self.fx_max:
                return
            self.parts_b.append([x + random.uniform(-4, 4), y, random.uniform(-12, 12),
                                 random.uniform(90, 170), 0.0, 0.32, col, 0.0, 4])

        def smoke(self, x, y):
            if len(self.parts) + len(self.parts_b) >= self.fx_max:
                return
            self.parts_b.append([x + random.uniform(-40, 40), y, random.uniform(-14, 14),
                                 random.uniform(-80, -40), 0.0, random.uniform(0.6, 1.0),
                                 "#8a8a99", 0.0, 6])

        def ring(self, x, y, ci, zmax, life=0.45):
            if self.fx <= 0 or len(self.rings) >= 6:
                return
            self.rings.append([x, y, 0.0, life, zmax, ci])

        def pimg(self, col, size, lv):
            key = (col, size, lv)
            d = self.pimg_cache.get(key)
            if d is None:
                d = Solid(col + ES_ALPHA_LV[lv], xysize=(size, size))
                self.pimg_cache[key] = d
            return d

        def ztf(self, d, z, a=1.0, zs=20, ast=8):
            """Imagen escalada y semitransparente en cache. Devuelve (imagen, zoom_real)."""
            zi = int(z * zs + 0.5)
            ai = max(0, min(ast, int(a * ast + 0.5)))
            key = (id(d), zi, ai, zs)
            tf = self.tf_cache.get(key)
            if tf is None:
                if len(self.tf_cache) > 600:
                    self.tf_cache = {}
                tf = Transform(d, zoom=max(0.02, zi / float(zs)), alpha=ai / float(ast))
                self.tf_cache[key] = tf
            return tf, max(0.02, zi / float(zs))

        def bank_step(self, bank, prev, x, dt):
            """Suaviza la inclinacion de la nave segun su velocidad lateral."""
            if dt <= 0:
                return bank, x
            target = max(-1.0, min(1.0, ((x - prev) / dt) / 500.0))
            bank += (target - bank) * min(1.0, dt * 9.0)
            return bank, x

        def bank_img(self, base, b):
            """(imagen, ancho, alto) de la nave inclinada: se ladea y se estrecha al girar."""
            lv = max(-6, min(6, int(round(b * 6))))
            key = (id(base), lv)
            v = self.bank_cache.get(key)
            if v is None:
                if lv == 0:
                    tf = renpy.displayable(base)
                else:
                    tf = Transform(renpy.displayable(base), rotate=lv * 16.0 / 6.0, rotate_pad=True,
                                   xzoom=1.0 - 0.10 * abs(lv) / 6.0, subpixel=True)
                w, h = renpy.render(tf, 400, 400, 0, 0).get_size()
                v = (tf, w, h)
                self.bank_cache[key] = v
            return v

        def vigtf(self, vi, a):
            ai = max(0, min(8, int(a * 8 + 0.5)))
            if ai == 0:
                return None
            key = (vi, ai)
            tf = self.vig_cache.get(key)
            if tf is None:
                tf = Transform(self.i_vig[vi], alpha=ai / 8.0)
                self.vig_cache[key] = tf
            return tf

        def flash_img(self, name):
            d = self.flash_cache.get(name)
            if d is None:
                d = im.MatrixColor(ES_IMG + "es_" + name + ".png", ES_FLASH_M)
                self.flash_cache[name] = d
            return d

        def queue_shot(self, bullets, marks, delay):
            """Ataque con aviso: marcas rojas arriba y las balas salen despues."""
            self.shots.append([delay, bullets, marks])

        def over_line(self, v):
            if self.endless:
                return u"Puntos: %d   Nivel: %d" % (v, self.stage)
            return u"Puntos: %d   Nivel: %d/%d" % (v, self.stage, self.nst)

        def trail_col(self):
            if self.sk == 8:
                return ES_COSMIC[int(self.elapsed * 6) % 3]
            return ES_SKIN_TRAIL[self.sk] if self.sk < len(ES_SKIN_TRAIL) else ES_SKIN_TRAIL[0]

        def amb_new(self, kind):
            if kind == "snow":
                return [random.uniform(0, ES_W), -6.0, random.uniform(-12, 12),
                        random.uniform(40, 90), random.uniform(0, 6.28)]
            if kind == "ember":
                return [random.uniform(0, ES_W), ES_H + 6.0, random.uniform(10, 40),
                        -random.uniform(50, 120), random.uniform(0, 6.28)]
            if kind == "spore":
                return [random.uniform(0, ES_W), ES_H + 6.0, random.uniform(-10, 10),
                        -random.uniform(15, 45), random.uniform(0, 6.28)]
            if kind == "dust":
                return [random.uniform(0, ES_W), -6.0, random.uniform(-25, -5),
                        random.uniform(20, 50), random.uniform(0, 6.28)]
            # void: entra por un borde y es atraido al centro
            a = random.uniform(0.0, 6.2832)
            px = ES_W / 2.0 + math.cos(a) * 760.0
            py = ES_H / 2.0 + math.sin(a) * 460.0
            return [px, py, -math.cos(a) * 55.0, -math.sin(a) * 40.0, 0.0]

        def fx_update(self, dt):
            # estado que no depende del nivel de efectos
            if self.hb_pulse > 0:
                self.hb_pulse -= dt
            tr = self.tier_of(self.combo)
            if tr > self.combo_tier and not self.over:
                self.sfx("combo_up")
                if self.fx > 0:
                    self.ring(self.px, self.py, 6, 1.8, 0.5)
                    self.spark(self.px, self.py, 12, ["#ffb347", "#ffe680"], spd=240, life=0.5)
                    self.add_float(self.px - 50, self.py - 60,
                                   u"¡Combo x%.1f!" % (self.combo_mult() / 10.0), "#ffb347")
            self.combo_tier = tr
            # temporizadores de parpadeo (corren siempre para que nada se quede encendido)
            if self.hflash:
                for k in list(self.hflash.keys()):
                    self.hflash[k] -= dt
                    if self.hflash[k] <= 0:
                        del self.hflash[k]
            if self.boss_flash > 0:
                self.boss_flash -= dt
            if self.vig_hurt > 0:
                self.vig_hurt -= dt
            if self.vig_ph2 > 0:
                self.vig_ph2 -= dt
            if self.sh_hit > 0:
                self.sh_hit -= dt
            dk = max(0.0, 1.0 - 7.0 * dt)
            self.brec = [self.brec[0] * dk, self.brec[1] * dk]
            if self.fx <= 0:
                self.hflash = {}
                return

            # particulas
            for P in (self.parts, self.parts_b):
                for p in P:
                    p[0] += p[2] * dt
                    p[1] += p[3] * dt
                    p[3] += p[7] * dt
                    p[4] += dt
            self.parts = [p for p in self.parts if p[4] < p[5]]
            self.parts_b = [p for p in self.parts_b if p[4] < p[5]]
            for rg in self.rings:
                rg[2] += dt
            self.rings = [rg for rg in self.rings if rg[2] < rg[3]]

            # cadena de explosiones (jefes y muerte del jugador)
            ch = self.chain
            if ch is not None:
                ch[0] -= dt
                if ch[0] <= 0:
                    ch[0] = 0.11
                    ch[1] -= 1
                    cx = ch[2] + random.uniform(-ch[4], ch[4])
                    cy = ch[3] + random.uniform(-ch[4] * 0.6, ch[4] * 0.6)
                    self.add_boom(cx, cy)
                    self.spark(cx, cy, 6, ES_SPARK_KILL, spd=200, life=0.5, grav=80)
                    if ch[1] % 3 == 0:
                        self.sfx("boom")
                    if ch[1] <= 0:
                        if ch[5]:
                            # explosion final: destello, anillo y lluvia de chispas
                            if self.fx >= 2:
                                self.flash = 0.35
                            self.shake = max(self.shake, 0.5)
                            self.ring(ch[2], ch[3], 0, 4.5, 0.7)
                            self.ring(ch[2], ch[3], ES_BOSS_FX[self.si % len(ES_BOSS_FX)][0], 3.0, 0.55)
                            self.spark(ch[2], ch[3], 40, ES_SPARK_KILL, spd=420, life=0.9, size=5, grav=140)
                        self.chain = None

            # rango: sello con anillo y confeti al aparecer
            if (self.phase == "clear" and self.rank_txt is not None and not self.rank_pop
                    and self.phase_t >= 0.4):
                self.rank_pop = True
                self.ring(ES_W / 2.0, 345, 1, 3.2, 0.6)
                if self.rank_ltr == "S":
                    self.spark(ES_W / 2.0, 345, 34, ES_CONFETTI, spd=380, life=1.1, size=5, grav=240)
                elif self.rank_ltr == "A":
                    self.spark(ES_W / 2.0, 345, 14, ES_CONFETTI, spd=300, life=0.9, size=4, grav=200)
                elif self.rank_ltr == "B":
                    self.spark(ES_W / 2.0, 345, 8, ES_CONFETTI, spd=240, life=0.8, size=4, grav=200)
                if self.rank_ltr in ("S", "A"):
                    self.ring(ES_W / 2.0, 345, 0, 4.4, 0.75)

            # rayos de la Tormenta Solar
            if self.si == 4 and self.phase in ("intro", "wave", "boss"):
                self.bolt_t -= dt
                if self.bolt_t <= 0:
                    self.bolt_t = random.uniform(3.0, 6.5)
                    self.bolt = [random.uniform(100, ES_W - 100), 0.0, random.randint(0, 2)]
            if self.bolt is not None:
                self.bolt[1] += dt
                if self.bolt[1] > 0.22:
                    self.bolt = None

            # ambiente del nivel (nieve, brasas, esporas...)
            cfg = ES_AMB.get(self.si)
            if cfg is not None and self.phase != "warp" and self.arrive_t <= 0:
                self.fx_amb_t -= dt
                if self.fx_amb_t <= 0 and len(self.amb) < (14 if self.fx == 1 else 28):
                    self.fx_amb_t = 0.3 if self.fx == 1 else 0.16
                    a = self.amb_new(cfg[0])
                    a += [cfg[0], cfg[1], cfg[2], 1 if cfg[0] == "snow" else 0]
                    self.amb.append(a)
            for a in self.amb:
                k = a[5]
                if k == "snow":
                    a[0] += (a[2] + math.sin(self.elapsed * 1.3 + a[4]) * 22.0) * dt
                elif k == "void":
                    a[2] *= 1.0 + 0.7 * dt
                    a[3] *= 1.0 + 0.7 * dt
                    a[0] += a[2] * dt
                else:
                    a[0] += a[2] * dt
                a[1] += a[3] * dt
            self.amb = [a for a in self.amb
                        if -40 < a[0] < ES_W + 40 and -40 < a[1] < ES_H + 40
                        and not (a[5] == "void" and abs(a[0] - ES_W / 2.0) < 30
                                 and abs(a[1] - ES_H / 2.0) < 30)]

        # ---------- acciones ----------
        def shoot(self):
            if len(self.bullets) > ES_MAX_BULLETS - 3:
                return
            x = self.px - 3
            y = self.py - 38
            if self.wl == 1:
                self.bullets.append([x, y, 0])
            elif self.wl == 2:
                self.bullets.append([x - 12, y, 0])
                self.bullets.append([x + 12, y, 0])
            else:
                self.bullets.append([x, y, 0])
                self.bullets.append([x - 14, y + 6, -140])
                self.bullets.append([x + 14, y + 6, 140])
            if self.fx >= 2:
                self.spark(self.px, self.py - 36, 1, "#ffffff", spd=40, life=0.12, size=6)
            self.sfx("shoot")

        def use_bomb(self, auto=False):
            if self.bombs <= 0 or self.over or self.paused or self.resume_t > 0:
                return
            self.bombs -= 1
            self.bombs_used += 1
            self.flash = 0.4
            self.shake = 0.35
            self.sfx("bomb")
            self.ring(self.px, self.py, 1, 6.0, 0.7)
            self.ring(self.px, self.py, 0, 4.0, 0.5)
            self.spark(self.px, self.py, 26, ["#ffe680", "#ffffff", "#ffb347"],
                       spd=420, life=0.6, size=5)
            for e in self.enemies:
                if e[5] > 0:
                    self.kill(e, False)
            self.ebullets = []
            self.shots = []
            es_hz_bomb(self)
            if self.boss is not None:
                bs_ = self.boss
                up_ = self.parts_up()
                if up_:
                    for p_ in up_:
                        self.hurt_part(bs_, p_, max(6, int(bs_[3] * self.bomb_pow * 0.6)))
                else:
                    for p_ in self.bparts:
                        if p_[4] > 0:
                            self.hurt_part(bs_, p_, max(8, int(bs_[3] * self.bomb_pow)))
            self.inv = max(self.inv, 0.6)
            if not auto:
                self.say("bomb")

        def drop(self, x, y, force=None, chance=0.11):
            if len(self.powerups) >= ES_MAX_POWERUPS:
                return
            if force is None:
                if random.random() > chance:
                    return
                force = random.choice(ES_DROPS)
            self.powerups.append([x, y, force])

        def kill(self, e, drops=True):
            e[5] = 0
            self.kills += 1
            self.stage_killed += 1
            self.combo += 1
            self.combo_t = self.combo_len
            if self.combo > self.maxcombo:
                self.maxcombo = self.combo
            self.add_score(ES_ESCORE[e[4]])
            w, h = ES_ESZ[e[4]]
            self.add_boom(e[7] + w / 2.0, e[1] + h / 2.0)
            self.sfx(self.boom_name())
            if self.fx > 0:
                kx = e[7] + w / 2.0
                ky = e[1] + h / 2.0
                big = e[4] in (3, 7)
                self.spark(kx, ky, 14 if big else 7,
                           ES_SPARK_ROCK if e[4] == 4 else ES_SPARK_KILL,
                           spd=220 if big else 160, life=0.5, size=4, grav=60)
                if big:
                    self.ring(kx, ky, 6, 0.9, 0.35)
            if drops and e[4] != 4:
                self.drop(e[7] + w / 2.0, e[1] + h / 2.0,
                          chance={3: 0.35, 7: 0.3, 6: 0.16}.get(e[4], 0.11) * self.drop_mult)
            if drops and e[4] == 7:
                # el carguero suelta dos enemigos basicos al romperse
                for dx in (-34, 34):
                    nx = max(40.0, min(ES_W - 100.0, e[7] + 14 + dx))
                    self.stage_spawned += 1
                    self.pending.append([nx, e[1] + 14, random.uniform(100, 150) + self.dsc * 9,
                                         random.uniform(0, 6.28), 0, 1, 99.0, nx])

        def hurt(self):
            self.hits += 1
            self.stage_hits += 1
            self.combo = 0
            if self.shield > 0:
                self.shield = 0.0
                self.inv = 1.0
                self.sh_hit = 0.35
                self.ring(self.px, self.py, 0, 2.6, 0.45)
                self.ring(self.px, self.py, 2, 1.7, 0.4)
                self.spark(self.px, self.py, 12, ["#6fd3ff", "#ffffff"], spd=260, life=0.4)
                self.sfx("hit")
                self.buzz(0.08)
                return
            if self.coop and self.m_save > 0:
                # Monika absorbe un golpe por nivel
                self.m_save -= 1
                self.inv = 1.4
                self.shake = 0.25
                self.add_float(self.px - 40, self.py - 50, u"¡Te cubro!", "#9bffb0")
                self.ring(self.px, self.py, 4, 1.5, 0.45)
                self.ring(self.mx, self.my, 4, 1.0, 0.45)
                self.sfx("hit")
                return
            if self.lives == 1 and self.autobomb and self.bombs > 0:
                self.use_bomb(True)
                self.inv = max(self.inv, 1.2)
                return
            self.lives -= 1
            self.lives_lost += 1
            ck = self.cause_key()
            self.death_log.append((self.si + 1, ck[0], ck[1]))
            self.inv = self.inv_hit
            self.shake = 0.25
            self.wl = max(1, self.wl - 1)
            self.add_boom(self.px, self.py)
            self.buzz(0.2)
            self.vig_hurt = 0.4
            self.spark(self.px, self.py, 16, ["#ff4466", "#ffb347", "#ffffff"], spd=300, life=0.5, grav=60)
            self.ring(self.px, self.py, 3, 1.6, 0.4)
            if self.fx >= 2:
                self.hitstop = 0.07
            if self.lives <= 0:
                if self.fx >= 1:
                    self.chain = [0.0, 8, self.px, self.py, 55.0, False]
                    self.ring(self.px, self.py, 0, 3.5, 0.6)
                    self.spark(self.px, self.py, 30, ES_SPARK_KILL, spd=380, life=0.9, size=5, grav=120)
                self.finish(False)
            else:
                self.sfx("hit")

        def laser_tick(self):
            x0 = self.px - 9
            for e in self.enemies:
                if e[5] <= 0:
                    continue
                w, h = ES_ESZ[e[4]]
                if (e[7] + w > x0 and e[7] < x0 + 18 and e[1] + h > 0
                        and e[1] < self.py - 20):
                    e[5] -= 1
                    self.hflash[id(e)] = 0.08
                    self.spark(self.px, e[1] + h, 2, ["#9fe8ff", "#ffffff"], spd=150, life=0.25, size=3)
                    if e[5] <= 0:
                        self.kill(e)
            bs = self.boss
            if bs is not None and bs[1] > -60:
                pt = self.part_hit(bs, x0, 0, 18, self.py - 20)
                if pt is not None:
                    if self.hurt_part(bs, pt, 2):
                        self.boss_flash = 0.05
                    self.spark(self.px, bs[1] + pt[1] + pt[3], 3,
                               ["#9fe8ff", "#ffffff"], spd=170, life=0.28, size=3)
            for b in self.ebullets:
                if abs(b[0] + 3 - self.px) < 14 and b[1] < self.py:
                    b[1] = ES_H + 100

        # ---------- jefes ----------
        def spawn_boss(self):
            n = self.stage
            hp = int((45 + 26 * (n - 1)) * self.D["boss"])
            self.boss = [ES_W / 2.0, -130.0, hp, hp, 1, 1.5]
            self.bparts = self.make_parts(False, hp)
            self.phase = "boss"
            self.phase_t = 0.0
            self.volley = 0
            self.ph2 = False
            self.sfx("warning")
            self.say("boss", True)
            self.set_music(self.boss_track())

        def bbox(self, bs):
            """(medio ancho, desfase superior, ancho, alto) de la caja de golpe."""
            if len(bs) > 6:
                return (52, 8, 104, 66)
            return (70, 10, 140, 90)

        # ---------- piezas destruibles de los jefes ----------
        def make_parts(self, mini, hp):
            """Piezas del jefe: [x, y, ancho, alto, vida, vida_max, exterior]
            (x, y relativos a la esquina del sprite). El nucleo (exterior=False)
            es invulnerable hasta destruir todas las piezas exteriores; al
            destruir el nucleo el jefe cae."""
            if mini:
                outer = [(0, 12, 42, 62, 0.30), (86, 12, 42, 62, 0.30)]
                core = (42, 4, 44, 80, 0.40)
            elif self.si >= 5:
                outer = [(0, 12, 50, 62, 0.16), (110, 12, 50, 62, 0.16),
                         (28, 80, 32, 32, 0.12), (100, 80, 32, 32, 0.12)]
                core = (50, 2, 60, 84, 0.44)
            else:
                outer = [(0, 12, 50, 62, 0.25), (110, 12, 50, 62, 0.25)]
                core = (50, 2, 60, 84, 0.50)
            parts = []
            for (x, y, w, h, f) in outer:
                v = max(4, int(hp * f))
                parts.append([x, y, w, h, v, v, True])
            (x, y, w, h, f) = core
            v = max(6, int(hp * f))
            parts.append([x, y, w, h, v, v, False])
            return parts

        def parts_up(self):
            return [p for p in self.bparts if p[6] and p[4] > 0]

        def part_hit(self, bs, x, y, w, h):
            """Pieza viva que toca el rectangulo dado (primero las exteriores)."""
            ox = bs[0] - (64 if len(bs) > 6 else 80)
            oy = bs[1]
            core = None
            for p in self.bparts:
                if p[4] <= 0:
                    continue
                if es_overlap(x, y, w, h, ox + p[0], oy + p[1], p[2], p[3]):
                    if p[6]:
                        return p
                    core = p
            return core

        def hurt_part(self, bs, p, dmg):
            """Dana una pieza. Devuelve False si el nucleo aun esta protegido."""
            if not p[6] and self.parts_up():
                return False
            p[4] -= dmg
            if p[4] <= 0 and p[6]:
                self.part_down(bs, p)
            core = [q for q in self.bparts if not q[6]]
            if core and core[0][4] <= 0:
                bs[2] = 0
            else:
                bs[2] = sum([max(0, q[4]) for q in self.bparts])
            return True

        def part_down(self, bs, p):
            ox = bs[0] - (64 if len(bs) > 6 else 80)
            cx = ox + p[0] + p[2] / 2.0
            cy = bs[1] + p[1] + p[3] / 2.0
            self.add_score(40 + 10 * min(self.stage, 12), False)
            self.add_boom(cx, cy)
            self.add_boom(cx + random.uniform(-15, 15), cy + random.uniform(-15, 15))
            self.sfx("boom")
            self.shake = max(self.shake, 0.3)
            self.buzz(0.12)
            self.spark(cx, cy, 14, ES_SPARK_KILL, spd=300, life=0.6, size=4, grav=100)
            self.big_boom(cx, cy, bs[6] if len(bs) > 6 else None, 0.6)
            if self.fx >= 1:
                self.brec = [random.choice((-9.0, 9.0)), -7.0]
            if self.fx >= 2:
                self.hitstop = 0.05
            self.drop(cx, cy, chance=0.35)
            if self.parts_up():
                self.add_float(cx - 60, cy - 24, u"¡Pieza destruida!", "#ffe066")
            else:
                self.add_float(cx - 60, cy - 24, u"¡Núcleo expuesto!", "#ff6688")

        def part_img(self, name, i, p, kind):
            key = (name, i, kind)
            d = self.part_cache.get(key)
            if d is None:
                crop = im.Crop(ES_IMG + "es_" + name + ".png", (p[0], p[1], p[2], p[3]))
                if kind == 0:     # pieza destruida: chamuscada
                    d = im.MatrixColor(crop, im.matrix.brightness(-0.55) * im.matrix.saturation(0.15))
                else:             # nucleo protegido: brillo de escudo
                    d = Transform(im.MatrixColor(crop, im.matrix.tint(0.5, 0.85, 1.0)), alpha=0.65)
                self.part_cache[key] = d
            return d

        def part_glow(self, col, w, h, alpha):
            key = ("gl", col, w, h, alpha)
            d = self.part_cache.get(key)
            if d is None:
                d = Solid(col + alpha, xysize=(w, h))
                self.part_cache[key] = d
            return d

        def part_bar(self, kind, w):
            key = ("pb", kind, w)
            d = self.part_cache.get(key)
            if d is None:
                d = Solid("#000000bb" if kind == 0 else "#ff4455",
                          xysize=(w, 6 if kind == 0 else 4))
                self.part_cache[key] = d
            return d

        def tint_img(self, name):
            key = ("tint", name)
            d = self.part_cache.get(key)
            if d is None:
                d = im.MatrixColor(ES_IMG + "es_" + name + ".png", im.matrix.tint(1.0, 0.68, 0.68))
                self.part_cache[key] = d
            return d

        def part_cracks(self, i, p, lvl):
            """Grietas de una pieza dañada (rectangulos [x, y, ancho, alto] fijos por pieza)."""
            key = ("ck", i, p[2], p[3], lvl)
            v = self.part_cache.get(key)
            if v is None:
                rng = random.Random(i * 977 + p[2] * 13 + p[3] + lvl)
                v = []
                for c in range(lvl):
                    x = int(p[2] * rng.uniform(0.3, 0.7))
                    y = int(p[3] * 0.2)
                    for k in range(5):
                        hh = rng.randint(6, 11)
                        v.append((x, y, 2, hh))
                        y += hh
                        ww = rng.randint(4, 8)
                        if rng.random() < 0.5:
                            v.append((x - ww, y, ww + 2, 2))
                            x -= ww
                        else:
                            v.append((x, y, ww + 2, 2))
                            x += ww
                        x = max(4, min(p[2] - 8, x))
                        if y > p[3] * 0.85:
                            break
                self.part_cache[key] = v
            return v

        def crack_solid(self, w, h):
            key = ("cs", w, h)
            d = self.part_cache.get(key)
            if d is None:
                d = Solid("#0c0c14e0", xysize=(w, h))
                self.part_cache[key] = d
            return d

        def draw_parts(self, bs, putw):
            mini = len(bs) > 6
            ox = bs[0] + self.brec[0] - (64 if mini else 80)
            oy = bs[1] + self.brec[1]
            name = ("mini%d" % bs[6]) if mini else ("boss%d" % self.si)
            exposed = not self.parts_up()
            for i, p in enumerate(self.bparts):
                x = ox + p[0]
                y = oy + p[1]
                if p[4] <= 0:
                    if p[6]:
                        putw(self.part_img(name, i, p, 0), x, y)
                    continue
                if not p[6] and not exposed:
                    if int(self.elapsed * 4) % 2 == 0:
                        putw(self.part_img(name, i, p, 1), x, y)
                    continue
                r_ = p[4] / float(p[5])
                if r_ < 0.66 and self.fx >= 1:
                    for (cx_, cy_, cw_, ch_) in self.part_cracks(i, p, 1 if r_ >= 0.33 else 2):
                        putw(self.crack_solid(cw_, ch_), x + cx_, y + cy_)
                w = max(1, int(p[2] * r_))
                putw(self.part_bar(0, p[2] + 2), x - 1, y - 8)
                putw(self.part_bar(1, w), x, y - 7)

        def spawn_mini(self):
            n = self.stage
            hp = max(14, int((45 + 26 * (n - 1)) * self.D["boss"] * 0.42))
            self.boss = [ES_W / 2.0, -110.0, hp, hp, random.choice((-1, 1)), 1.2, self.si]
            self.bparts = self.make_parts(True, hp)
            self.mini_done = True
            self.mini_t = 2.0
            self.mini_txt = [self.T(u"¡MINI-JEFE!", 70, "#ffb347"),
                             Text(ES_MINI[self.si][0], size=36, color="#ffffff",
                                  outlines=[(2, "#000000", 0, 0)])]
            self.sfx("warning")
            self.say("mini", True)

        def mini_down(self, bs):
            self.minis += 1
            self.add_score(150 + 60 * min(self.stage, 12), False)
            for i in range(4):
                self.add_boom(bs[0] + random.uniform(-50, 50), bs[1] + random.uniform(10, 70))
            self.sfx("boom")
            self.shake = 0.35
            self.buzz(0.2)
            if self.fx >= 1:
                self.chain = [0.0, 4, bs[0], bs[1] + 45, 45.0, False]
                self.ring(bs[0], bs[1] + 45, 6, 2.2, 0.5)
                self.spark(bs[0], bs[1] + 45, 20, ES_SPARK_KILL, spd=300, life=0.7, size=4, grav=100)
            if self.fx >= 2:
                self.hitstop = 0.06
            self.big_boom(bs[0], bs[1] + 45, bs[6], 0.9)
            self.drop(bs[0], bs[1] + 50, chance=2.0)
            self.ebullets = []
            self.shots = []
            self.boss = None
            self.bparts = []
            self.say("clear", True)

        def boss_fire(self, bs):
            if len(self.ebullets) > ES_MAX_EBULLETS - 12:
                return
            if len(bs) > 6:
                pats = ES_MINI[bs[6]][1]
            else:
                pats = ES_PATTERNS[self.si]
                if self.ph2:
                    pats = pats + ["wide"]
            pat = pats[self.volley % len(pats)]
            self.volley += 1
            x = bs[0]
            y = bs[1] + (72 if len(bs) > 6 else 100)
            E = self.ebullets
            if pat == "volley":
                for dx in (-60, 0, 60):
                    E.append([x + dx - 3, y, 0])
            elif pat == "fan":
                for vx in (-270, -180, -90, 0, 90, 180, 270):
                    E.append([x - 3, y, vx])
            elif pat == "wide":
                for i in range(10):
                    E.append([x - 3, y, -300 + 600 * i / 9.0])
            elif pat == "aimed":
                vy = (300 + self.dsc * 12) * self.D["bspd"]
                dy = max(40.0, self.py - y)
                for off in (-70, 0, 70):
                    vx = (self.px - (x + off)) / dy * vy
                    E.append([x + off - 3, y, max(-380, min(380, vx))])
            elif pat == "rain":
                xs = [random.uniform(40, ES_W - 40) for i in range(6)]
                self.queue_shot([[xx, -10, 0] for xx in xs], [xx + 3 for xx in xs], 0.45)
            elif pat == "walls":
                # pared de balas con un hueco de 3 espacios
                gap = random.randint(1, 9)
                xs = [60 + i * 116 - 3 for i in range(11) if abs(i - gap) > 1]
                self.queue_shot([[xx, -10, 0] for xx in xs], [xx + 3 for xx in xs], 0.55)
            elif pat == "zigzag":
                # abanico inclinado que cambia de lado en cada disparo
                self.spiral += 1.0
                d = 1 if int(self.spiral) % 2 else -1
                for k in range(5):
                    E.append([x - 3, y, d * (40 + 70 * k)])
            else:   # spiral
                self.spiral += 0.55
                for i in range(4):
                    E.append([x - 3, y, 250 * math.sin(self.spiral + i * 1.5708)])

        def boss_down(self, bs):
            self.bosses += 1
            self.add_score(300 + 150 * min(self.stage, 12), False)
            for i in range(5):
                self.add_boom(bs[0] + random.uniform(-70, 70),
                              bs[1] + random.uniform(10, 90))
            self.sfx("boom")
            self.shake = 0.6
            if self.fx >= 1:
                self.chain = [0.0, 9, bs[0], bs[1] + 50, 80.0, True]
                self.slowmo = 0.9
                self.spark(bs[0], bs[1] + 50, 28, ES_SPARK_KILL, spd=360, life=0.8, size=5, grav=100)
            if self.fx >= 2:
                self.hitstop = 0.12
            if self.coop:
                self.m_save = 1
            self.big_boom(bs[0], bs[1] + 50, None, 1.5)
            self.buzz(0.3)
            # rango del nivel
            hits = self.stage_hits
            ratio = self.stage_killed / float(max(1, self.stage_spawned))
            pts = (2 if hits == 0 else (1 if hits == 1 else 0))
            pts += 2 if ratio >= 0.85 else (1 if ratio >= 0.6 else 0)
            pts += 1 if self.phase_t < 16 + 2 * min(self.stage, 8) else 0
            rank = "S" if pts >= 5 else ("A" if pts == 4 else ("B" if pts >= 2 else "C"))
            bonus = ES_RANK_BONUS[rank]
            self.score += bonus
            self.ranks.append((self.stage, rank))
            self.rank_ltr = rank
            self.rank_pop = False
            self.rank_txt = self.T(u"Rango %s   +%d" % (rank, bonus), 54,
                                   {"S": "#ffe066", "A": "#9bffb0", "B": "#9fd0ff",
                                    "C": "#cccccc"}[rank])
            self.rank_big = Text(rank, size=170, color={"S": "#ffe066", "A": "#9bffb0", "B": "#9fd0ff",
                                                         "C": "#cccccc"}[rank], bold=True,
                                 outlines=[(5, "#000000", 0, 0)])
            self.say("rankS" if rank == "S" else "clear", True)
            # limpiar pantalla
            for e in self.enemies:
                if e[5] > 0:
                    self.add_boom(e[7] + 30, e[1] + 25)
            self.enemies = []
            self.pending = []
            self.powerups = self.powerups[:2] + [
                [bs[0] - 40, bs[1] + 60, 2 if self.lives < 5 else 3],
                [bs[0] + 40, bs[1] + 60, 0]]
            self.ebullets = []
            self.shots = []
            self.boss = None
            self.bparts = []
            self.phase = "clear"
            self.phase_t = 0.0
            renpy.music.stop(channel="es_music", fadeout=0.6)
            self.sfx("clear")

        # ---------- salto hiperespacial entre niveles ----------
        def begin_warp(self, kind):
            self.phase = "warp"
            self.phase_t = 0.0
            self.warp_kind = kind
            n = self.stage + 1
            self.warp_n = n
            self.warp_story = (self.mode == "story" and kind == "stage")
            self.warp_story_done = False
            self.warp_launched = False
            self.enemies = []
            self.pending = []
            self.mini_t = 0.0
            self.ebullets = []
            self.shots = []
            self.bullets = []
            self.powerups = []
            self.boss = None
            self.bparts = []
            self.laser = 0.0
            self.say_t = 0.0
            es_hz_clear(self)
            if kind == "stage":
                nm = ES_STAGES[(n - 1) % ES_NST][0]
                self.wp_title = [self.T(u"NIVEL %d" % n, 80, "#ffffff"),
                                 Text(nm, size=42, color="#ffe680", outlines=[(2, "#000000", 0, 0)])]
            else:
                self.wp_title = [self.T(u"NIVEL BONUS", 80, "#ffe066"),
                                 Text(u"¡Esquiva las rocas y atrapa monedas!", size=38, color="#ffffff",
                                      outlines=[(2, "#000000", 0, 0)])]
            self.wp_tf = {}
            self.amb = []
            self.wp_lines = [[random.uniform(0, ES_W), random.uniform(-ES_H, ES_H),
                              random.uniform(0.6, 1.4), random.randint(0, 1)]
                             for _i in range(34)]
            self.star_mul = 1.0
            self.ship_dy = 0.0
            self.wp_black = 0.0
            self.sfx("warp")

        def warp_update(self, dt):
            t = self.phase_t
            if t < self.WP_A:
                # carga: la nave tiembla y las estrellas empiezan a estirarse
                k = t / self.WP_A
                self.star_mul = 1.0 + 3.0 * k * k
                self.ship_dy = 0.0
                self.shake = max(self.shake, 0.08 + 0.3 * k)
            elif t < self.WP_B:
                # impulso: la nave sale disparada hacia arriba
                tb = t - self.WP_A
                if not self.warp_launched:
                    self.warp_launched = True
                    self.ring(self.px, self.py, 0, 5.0, 0.6)
                    self.spark(self.px, self.py + 20, 20, ["#ffe680", "#ffffff", "#9fe8ff"], spd=380, life=0.6)
                    self.flash = 0.42
                    self.shake = 0.5
                    self.buzz(0.25)
                self.star_mul = 4.0 + 26.0 * min(1.0, tb / 0.45)
                self.ship_dy = -1300.0 * tb * tb
            elif t < self.WP_C:
                # el escenario queda atras y la pantalla se funde a negro
                self.star_mul = 30.0
                self.ship_dy = -2400.0
                self.wp_black = (t - self.WP_B) / (self.WP_C - self.WP_B)
            else:
                self.star_mul = 30.0
                self.ship_dy = -2400.0
                self.wp_black = 1.0
                if self.warp_story and not self.warp_story_done:
                    # modo Historia: en la pantalla negra entra la escena
                    renpy.end_interaction(("story", "s%d" % (self.warp_n - 1)))
                elif t >= self.WP_D:
                    self.finish_warp()

        def finish_warp(self):
            if self.warp_kind == "bonus":
                self.start_bonus()
            else:
                self.start_stage(self.warp_n)
            self.arrive_t = self.WP_ARR
            self.ring(self.px, self.py, 2, 3.5, 0.7)
            self.star_mul = 12.0
            self.ship_dy = 340.0
            self.wp_black = 1.0
            self.fire_t = 0.3
            self.sfx("arrive")

        def story_resume(self):
            """Se llama al volver de una escena de historia."""
            self.warp_story_done = True
            self.phase_t = self.WP_C + 0.45
            self.last_st = None
            self.down = False

        def streak(self, h, k):
            h = max(16, (int(h) // 16) * 16)
            key = (h, k)
            s = self.streak_cache.get(key)
            if s is None:
                cols = ["#9fb8ff90", "#ffffffd0", "#6fd3ff60", "#ffe6a060", "#ff7a5a70"]
                s = Solid(cols[k], xysize=(2 if k in (0, 2, 4) else 4, h))
                self.streak_cache[key] = s
            return s

        def wp_alpha(self, i, a):
            key = (i, int(a * 10 + 0.5))
            tf = self.wp_tf.get(key)
            if tf is None:
                tf = Transform(self.wp_title[i], alpha=key[1] / 10.0)
                self.wp_tf[key] = tf
            return tf

        # ---------- logica ----------
        def spawn_enemy(self):
            s = self.dsc
            w = ES_STAGES[self.si][2]
            r = random.uniform(0, sum(w))
            kind = 0
            for i, v in enumerate(w):
                r -= v
                if r <= 0:
                    kind = ES_KINDMAP[i]
                    break
            bx = random.uniform(80, ES_W - 80)
            if kind == 0:
                spd = random.uniform(80, 130) + s * 9
                hp = 1
            elif kind == 1:
                spd = random.uniform(80, 130) * 0.7 + s * 7
                hp = 3
            elif kind == 2:
                spd = 250 + s * 12
                hp = 1
            elif kind == 5:
                spd = 150 + s * 8
                hp = 1
            elif kind == 6:
                spd = 170.0
                hp = 3 + s // 5
            elif kind == 7:
                spd = 50 + s * 3
                hp = 5 + s
            else:
                spd = 55 + s * 5
                hp = 6 + s
            self.stage_spawned += 1
            self.enemies.append([bx, -70.0, spd, random.uniform(0, 6.28),
                                 kind, hp, random.uniform(0.8, 1.8), bx,
                                 (4.2 if kind == 6 else 0.0)])

        def spawn_rock(self):
            bx = random.uniform(60, ES_W - 60)
            self.enemies.append([bx, -60.0, random.uniform(170, 260), 0.0,
                                 4, 2, 99.0, bx])

        def update(self, dt):
            smul = self.star_mul      # 1 normal; mucho mas en el salto hiperespacial
            for s in self.stars:
                s[1] += s[2] * dt * smul
                if s[1] > ES_H:
                    s[1] = -4
                    s[0] = random.uniform(0, ES_W)
            for d_ in self.dust:
                d_[1] += d_[2] * dt * smul
                if d_[1] > ES_H:
                    d_[1] = -4
                    d_[0] = random.uniform(0, ES_W)
            if self.fx >= 1 and self.phase in ("intro", "wave", "boss", "clear"):
                self.fr_t -= dt
                if self.fr_t <= 0 and len(self.far_rocks) < 3:
                    self.fr_t = random.uniform(4.0, 9.0)
                    self.far_rocks.append([random.uniform(60, ES_W - 60), -60.0, random.uniform(28, 60),
                                           random.uniform(-14, 14), random.uniform(0.3, 0.6)])
            for fr in self.far_rocks:
                fr[1] += fr[2] * dt * smul
                fr[0] += fr[3] * dt
            self.far_rocks = [fr for fr in self.far_rocks if fr[1] < ES_H + 60]
            if smul > 1.5:
                for L in self.wp_lines:
                    L[1] += 520.0 * L[2] * min(smul, 14.0) * dt
                    if L[1] > ES_H + 40:
                        L[1] = random.uniform(-500, -20)
                        L[0] = random.uniform(0, ES_W)

            self.neb_y = (self.neb_y + ES_NEB_SPD * dt * smul) % ES_H
            if self.planet is not None:
                self.planet[1] += ES_PLANET_SPD * dt * smul
                if self.planet[1] > ES_H + 160:
                    self.planet = None

            for b in self.booms:
                b[2] += dt
            self.booms = [b for b in self.booms if b[2] < 0.32]
            if self.flash > 0:
                self.flash -= dt
            if self.shake > 0:
                self.shake -= dt
            for f in self.floats:
                f[1] -= 55 * dt
                f[2] += dt
            self.floats = [f for f in self.floats if f[2] < 0.9]
            for tt in self.toasts:
                tt[1] -= dt
            self.toasts = [tt for tt in self.toasts if tt[1] > 0]
            if self.say_t > 0:
                self.say_t -= dt
            if self.say_cd > 0:
                self.say_cd -= dt
            self.fx_update(dt)

            if self.over:
                self.over_t += dt
                if self.leaving:
                    self.leave_t += dt
                    if self.leave_t >= 0.8:
                        renpy.end_interaction(self.summary())
                return

            # llegada al nivel nuevo: sale de la pantalla negra y frena
            if self.arrive_t > 0:
                self.arrive_t = max(0.0, self.arrive_t - dt)
                kk = self.arrive_t / self.WP_ARR
                self.star_mul = 1.0 + 11.0 * kk * kk * kk
                self.ship_dy = 340.0 * kk * kk
                self.wp_black = max(0.0, (kk - 0.62) / 0.38)
                if self.arrive_t <= 0:
                    self.star_mul = 1.0
                    self.ship_dy = 0.0
                    self.wp_black = 0.0

            st = self.dsc
            self.elapsed += dt
            self.ach_t -= dt
            if self.ach_t <= 0:
                self.ach_t = 0.5
                self.check_live()
            self.phase_t += dt
            for name in ("inv", "shield", "rapid", "x2", "magnet", "drones",
                         "laser", "slow", "ph2_t", "mini_t"):
                v = getattr(self, name)
                if v > 0:
                    setattr(self, name, v - dt)
            if self.combo > 0:
                self.combo_t -= dt
                if self.combo_t <= 0:
                    self.combo = 0

            # tiempo "lento" para enemigos y sus balas
            edt = dt * 0.5 if self.slow > 0 else dt

            # fases del nivel
            if self.phase == "intro":
                if self.phase_t > 2.5:
                    self.phase = "wave"
                    self.phase_t = 0.0
            elif self.phase == "wave":
                self.stage_t += dt
                tb = 28 + 2 * min(st, 8)
                if (not self.mini_done and not self.practice and self.stage >= 2
                        and self.boss is None and self.stage_t >= tb * 0.5):
                    self.spawn_mini()
                if self.stage_t >= tb and self.boss is None:
                    self.spawn_boss()
            elif self.phase == "clear":
                if self.phase_t > 3.0:
                    if self.practice:
                        self.finish(True)
                        return
                    if not self.endless and self.stage >= self.nst:
                        self.finish(True)
                        return
                    self.begin_warp("bonus" if self.si in (2, 5) else "stage")
            elif self.phase == "bonus":
                if self.phase_t > 15.0:
                    self.begin_warp("stage")

            # salto hiperespacial: la nave acelera, deja el escenario y se pasa
            # por una pantalla negra al siguiente nivel (sin disparos ni choques)
            if self.phase == "warp":
                self.warp_update(dt)
                return

            # nave del jugador (suavizada). La decoracion de nivel nunca la empuja ni la frena
            es_hz_update(self, dt)
            if self.hz_slide:
                es_hz_slide(self, dt)
            else:
                self.ivx = 0.0
                self.ivy = 0.0
                k = min(1.0, dt * self.mv_k)
                self.px += (self.tx - self.px) * k
                self.py += (self.ty - self.py) * k
            self.bank, self.bank_px = self.bank_step(self.bank, self.bank_px, self.px, dt)
            if dt > 0:
                vy_ = abs(self.py - self.eng_py) / dt
                self.eng_py = self.py
                self.eng += (min(1.0, vy_ / 400.0 + abs(self.bank) * 0.9) - self.eng) * min(1.0, dt * 8.0)
            if self.fx >= 2 and not self.over:
                self.ghost_t -= dt
                if abs(self.bank) > 0.55 and self.ghost_t <= 0 and len(self.ghosts) < 8:
                    self.ghost_t = 0.045
                    self.ghosts.append([self.px, self.py, self.bank, 0.0])
            for g_ in self.ghosts:
                g_[3] += dt
            self.ghosts = [g_ for g_ in self.ghosts if g_[3] < 0.28]

            if self.coop:
                self.monika_update(dt)
                self.mbank, self.bank_mx = self.bank_step(self.mbank, self.bank_mx, self.mx, dt)

            # estela del motor y latido cuando queda una sola vida
            if self.fx > 0:
                self.fx_trail_t -= dt
                if self.fx_trail_t <= 0:
                    self.fx_trail_t = 0.035 if self.fx >= 2 else 0.08
                    self.trail(self.px, self.py + 24, self.trail_col())
                    if self.coop:
                        self.trail(self.mx, self.my + 24, "#9bffb0")
            if self.lives == 1 and not self.over:
                self.hb_t -= dt
                if self.hb_t <= 0:
                    self.hb_t = 1.15
                    self.hb_pulse = 0.4
                    self.sfx4("heartbeat")
            else:
                self.hb_t = 0.0

            # disparo automatico
            self.fire_t -= dt
            if self.fire_t <= 0:
                base = 0.2 if self.wl < 3 else 0.17
                self.fire_t = base * (0.55 if self.rapid > 0 else 1.0) * self.fire_mul
                self.shoot()

            # drones
            if self.drones > 0:
                self.dang += dt * 3.2
                self.dr_t -= dt
                if self.dr_t <= 0:
                    self.dr_t = 0.45
                    if len(self.bullets) < ES_MAX_BULLETS - 2:
                        for (dx, dy) in self.drone_pos():
                            self.bullets.append([self.px + dx - 3, self.py + dy - 14, 0])

            # laser
            if self.laser > 0:
                self.laser_t -= dt
                if self.laser_t <= 0:
                    self.laser_t = 0.1
                    self.laser_tick()

            # balas y power-ups
            for b in self.bullets:
                b[1] -= 760 * dt
                b[0] += b[2] * dt
            self.bullets = [b for b in self.bullets
                            if b[1] > -20 and -20 < b[0] < ES_W + 20]
            vy = (300 + st * 12) * self.D["bspd"] * edt
            for b in self.ebullets:
                b[1] += vy
                b[0] += b[2] * edt
            self.ebullets = [b for b in self.ebullets
                             if b[1] < ES_H + 20 and -20 < b[0] < ES_W + 20]
            # ataques con aviso: cuando termina la cuenta salen las balas
            if self.shots:
                for sh in self.shots:
                    sh[0] -= edt
                due = [sh for sh in self.shots if sh[0] <= 0]
                if due:
                    self.shots = [sh for sh in self.shots if sh[0] > 0]
                    for sh in due:
                        room = ES_MAX_EBULLETS - len(self.ebullets)
                        if room > 0:
                            self.ebullets.extend(sh[1][:room])
            for p in self.powerups:
                if self.magnet > 0:
                    dx = self.px - p[0]
                    dy = self.py - p[1]
                    d = math.hypot(dx, dy) + 0.01
                    if d < 380:
                        p[0] += dx / d * 430 * dt
                        p[1] += dy / d * 430 * dt
                        continue
                p[1] += 150 * dt
            self.powerups = [p for p in self.powerups if p[1] < ES_H + 40]

            # jefe
            bs = self.boss
            if bs is not None:
                if bs[2] <= 0:
                    if len(bs) > 6:
                        self.mini_down(bs)
                    else:
                        self.boss_down(bs)
                    bs = None
                else:
                    if len(bs) < 7 and not self.ph2 and bs[1] >= 60 and not self.parts_up():
                        self.ph2 = True
                        self.ph2_t = 1.8
                        self.ebullets = []
                        self.shots = []
                        self.sfx("warning")
                        self.sfx("ph2")
                        self.vig_ph2 = 1.6
                        self.shake = max(self.shake, 0.4)
                        self.ring(bs[0], bs[1] + 60, 3, 3.0, 0.7)
                        self.ring(bs[0], bs[1] + 60, 6, 2.0, 0.5)
                        self.spark(bs[0], bs[1] + 60, 18, ["#ff4466", "#ffb347", "#ffffff"], spd=300, life=0.7)
                        if self.fx >= 2:
                            self.hitstop = 0.06
                        self.say("phase2", True)
                    if bs[1] < 60:
                        bs[1] += 90 * dt
                    else:
                        spd = (110 + st * 18) * (1.3 if self.ph2 else 1.0)
                        bs[0] += bs[4] * spd * edt
                        if bs[0] > ES_W - 100:
                            bs[4] = -1
                        elif bs[0] < 100:
                            bs[4] = 1
                        bs[5] -= edt
                        if bs[5] <= 0:
                            iv = max(0.55, 1.4 - 0.1 * st) * (0.75 if self.ph2 else 1.0)
                            if len(bs) > 6:
                                iv *= 1.25
                            bs[5] = iv
                            self.boss_fire(bs)

            # humo del jefe cuando esta en fase 2 o muy dañado
            if bs is not None and self.fx >= 1 and bs[1] >= 40 and (
                    (self.ph2 and len(bs) < 7) or bs[2] < bs[3] * 0.25):
                self.fx_smoke_t -= dt
                if self.fx_smoke_t <= 0:
                    self.fx_smoke_t = 0.14
                    self.smoke(bs[0], bs[1] + 60)

            # humo de las piezas destruidas
            if bs is not None and self.fx >= 1 and bs[1] >= 40 and self.bparts:
                self.fx_psmoke_t -= dt
                if self.fx_psmoke_t <= 0:
                    self.fx_psmoke_t = 0.22
                    ox0 = bs[0] - (64 if len(bs) > 6 else 80)
                    for p in self.bparts:
                        pcx = ox0 + p[0] + p[2] / 2.0
                        pcy = bs[1] + p[1] + p[3] / 2.0
                        if p[6] and p[4] <= 0:
                            self.smoke(pcx, pcy)
                        elif p[4] > 0 and p[4] < p[5] * 0.4:
                            self.spark(pcx + random.uniform(-p[2] * 0.3, p[2] * 0.3),
                                       pcy + random.uniform(-p[3] * 0.3, p[3] * 0.3), 2,
                                       ["#ffb347", "#ffffff"], spd=90, life=0.3, size=3)
                            if p[4] < p[5] * 0.2:
                                self.debris(pcx, pcy, 1, spd=80, grav=400.0, size=3, life=0.6)

            # aparicion de enemigos
            if self.phase == "bonus":
                if self.phase_t > 1.5:
                    self.spawn_t -= dt
                    if self.spawn_t <= 0:
                        self.spawn_t = 0.42
                        if len(self.enemies) < ES_MAX_ENEMIES:
                            self.spawn_rock()
                    self.coin_t -= dt
                    if self.coin_t <= 0:
                        self.coin_t = 0.65
                        if len(self.powerups) < 10 and self.phase_t < 13.5:
                            self.powerups.append([random.uniform(60, ES_W - 60), -20.0, 6])
            elif self.phase in ("wave", "boss") or (self.phase == "intro" and self.phase_t > 1.2):
                self.spawn_t -= dt
                if self.spawn_t <= 0:
                    base = max(0.38, 1.25 - st * 0.1) * self.D["spawn"]
                    self.spawn_t = base * (2.4 if self.boss else 1.0)
                    if len(self.enemies) < (4 if self.boss else ES_MAX_ENEMIES):
                        self.spawn_enemy()

            # mover enemigos
            for e in self.enemies:
                kind = e[4]
                e[1] += e[2] * edt
                if kind == 2:       # kamikaze: persigue en horizontal
                    dx = (self.px - e[7]) * 2.0
                    e[7] += max(-200.0, min(200.0, dx)) * edt
                elif kind == 4:     # roca
                    e[7] = e[0]
                elif kind == 5:     # dardo: zigzag amplio y rapido
                    e[7] = max(20.0, min(ES_W - 76.0, e[0] + math.sin(self.elapsed * 4.5 + e[3]) * 170))
                elif kind == 6:     # francotirador: baja, se detiene, apunta y se va
                    e[7] = e[0] + math.sin(self.elapsed * 1.2 + e[3]) * 25
                    if e[1] < 95 and e[8] > 0:
                        e[2] = 170.0
                    elif e[8] > 0:
                        e[2] = 0.0
                        e[8] -= edt
                    else:
                        e[2] = 260.0
                elif kind == 7:     # carguero: lento, se divide al morir
                    e[7] = e[0] + math.sin(self.elapsed * 1.4 + e[3]) * 40
                else:
                    e[7] = e[0] + math.sin(self.elapsed * 2.0 + e[3]) * 60
                if kind == 1 or kind == 3:
                    e[6] -= edt
                    if e[6] <= 0 and e[1] > 0:
                        w = ES_ESZ[kind][0]
                        if len(self.ebullets) < ES_MAX_EBULLETS - 4:
                            if kind == 1:
                                e[6] = max(0.9, 2.0 - st * 0.1)
                                self.ebullets.append([e[7] + w / 2 - 3, e[1] + 45, 0])
                            else:
                                e[6] = max(1.3, 2.4 - st * 0.1)
                                for vx in (-110, 0, 110):
                                    self.ebullets.append([e[7] + w / 2 - 3, e[1] + 55, vx])
                        else:
                            e[6] = 0.5
                if kind == 6 and e[2] == 0.0:
                    e[6] -= edt
                    if e[6] <= 0:
                        if len(self.ebullets) < ES_MAX_EBULLETS - 4:
                            e[6] = max(1.1, 1.9 - st * 0.06)
                            sx = e[7] + 30
                            sy = e[1] + 52
                            vy = (300 + st * 12) * self.D["bspd"]
                            dy = max(40.0, self.py - sy)
                            vx = max(-380.0, min(380.0, (self.px - sx) / dy * vy))
                            self.ebullets.append([sx - 3, sy, vx])
                        else:
                            e[6] = 0.5

            # balas vs enemigos
            for e in self.enemies:
                if e[5] <= 0:
                    continue
                w, h = ES_ESZ[e[4]]
                for b in self.bullets:
                    if b[1] < -50:
                        continue
                    if es_overlap(b[0], b[1], 6, 18, e[7] + 4, e[1] + 4, w - 8, h - 8):
                        self.spark(b[0] + 3, b[1] + 4, 2, ES_SPARK_HIT, spd=140, life=0.28, size=3)
                        self.hflash[id(e)] = 0.08
                        b[1] = -100
                        e[5] -= 2 if (self.crit and random.random() < self.crit) else 1
                        if e[5] <= 0:
                            self.kill(e)
                        break

            # balas vs jefe (por piezas)
            if bs is not None:
                for b in self.bullets:
                    if b[1] < -50:
                        continue
                    pt = self.part_hit(bs, b[0], b[1], 6, 18)
                    if pt is not None:
                        hx_, hy_ = b[0] + 3, b[1] + 4
                        b[1] = -100
                        if self.hurt_part(bs, pt, 2 if (self.crit and random.random() < self.crit) else 1):
                            self.spark(hx_, hy_, 2, ES_SPARK_HIT, spd=140, life=0.28, size=3)
                            if self.fx >= 2:
                                self.debris(hx_, hy_, 1, spd=140, grav=420.0, size=3, life=0.5)
                            self.boss_flash = 0.06
                        else:
                            # el nucleo esta protegido: la bala rebota
                            self.spark(hx_, hy_, 3, ["#66ccff", "#ffffff"],
                                       spd=160, life=0.25, size=3)

            self.bullets = [b for b in self.bullets if b[1] > -20]
            self.enemies = [e for e in self.enemies
                            if e[5] > 0 and e[1] < ES_H + 70]
            if self.pending:
                self.enemies += self.pending
                self.pending = []

            # recoger power-ups
            for p in self.powerups:
                pd = self.pick_pad
                if es_overlap(self.px - 22 - pd, self.py - 24 - pd, 44 + 2 * pd, 48 + 2 * pd,
                              p[0] - 18, p[1] - 18, 36, 36):
                    t = p[2]
                    s0 = self.score
                    d = self.pu_dur
                    if t != 6:
                        self.pu_count += 1
                        self.pu_types.add(t)
                    if t == 0:
                        if self.wl < 3:
                            self.wl += 1
                        else:
                            self.add_score(50, False)
                    elif t == 1:
                        self.shield = 8.0 * d * self.shield_mult
                    elif t == 2:
                        if self.lives < 5:
                            self.lives += 1
                            self.say("life")
                        else:
                            self.add_score(50, False)
                    elif t == 3:
                        if self.bombs < 3:
                            self.bombs += 1
                        else:
                            self.add_score(50, False)
                    elif t == 4:
                        self.rapid = 10.0 * d
                    elif t == 5:
                        self.x2 = 15.0 * d
                    elif t == 6:
                        self.coins += 1
                        self.add_score(30, False)
                    elif t == 7:
                        self.magnet = 10.0 * d
                    elif t == 8:
                        self.drones = 14.0 * d
                        self.say("drones")
                    elif t == 9:
                        self.laser = 5.0 * d
                        self.laser_t = 0.0
                        self.say("laser")
                    else:
                        self.slow = 6.0 * d
                    nm = ES_PU_NAMES[t]
                    if t in (0, 2, 3) and self.score > s0:
                        nm = u"+%d" % (self.score - s0)
                    self.add_float(p[0] - 20, p[1] - 30, nm, ES_PU_COL[t])
                    self.ring(self.px, self.py, ES_PU_RING[t], 1.0 if t == 6 else 1.5, 0.35 if t == 6 else 0.45)
                    self.spark(p[0], p[1], 3 if t == 6 else 9, ES_PU_COL[t], spd=190, life=0.4)
                    p[1] = ES_H + 100
                    self.sfx("pickup")
            self.powerups = [p for p in self.powerups if p[1] < ES_H + 40]

            # roces: puntos por pasar cerca de una bala sin que te toque
            if self.inv <= 0 and not self.over:
                for b in self.ebullets:
                    if (len(b) == 3 and abs(b[0] + 3 - self.px) < 30
                            and abs(b[1] + 7 - self.py) < 30):
                        b.append(1)
                        self.spark(b[0] + 3, b[1] + 7, 2, ["#ffffff", "#ffe680"], spd=120, life=0.25, size=3)
                        self.grazes += 1
                        self.add_score(self.graze_pts, False)
                        if self.grazes in (25, 50, 100):
                            self.say("graze")

            # choques con el jugador (solo cuenta el nucleo de la nave: 12x14)
            if self.inv <= 0 and not self.over:
                hit = False
                cx = self.px - 6
                cy = self.py - 7
                for e in self.enemies:
                    w, h = ES_ESZ[e[4]]
                    if es_overlap(cx, cy, 12, 14,
                                  e[7] + 8, e[1] + 8, w - 16, h - 16):
                        self.add_boom(e[7] + w / 2.0, e[1] + h / 2.0)
                        e[5] = 0
                        hit = True
                for b in self.ebullets:
                    if es_overlap(cx, cy, 12, 14, b[0], b[1], 6, 15):
                        b[1] = ES_H + 100
                        hit = True
                if bs is not None and es_overlap(cx, cy, 12, 14,
                                                 bs[0] - self.bbox(bs)[0], bs[1] + self.bbox(bs)[1],
                                                 self.bbox(bs)[2], self.bbox(bs)[3]):
                    hit = True
                if hit:
                    self.hurt()

        # ---------- companera Monika (IA) ----------
        def monika_update(self, dt):
            if self.m_stun > 0:
                self.m_stun -= dt
            if self.m_inv > 0:
                self.m_inv -= dt

            # destino: a un lado de la nave del jugador
            gx = self.px + self.m_side * 110
            if gx < 50 or gx > ES_W - 50:
                self.m_side = -self.m_side
                gx = self.px + self.m_side * 110
            gy = self.py + 20

            # esquivar balas que vienen hacia ella
            push = 0
            for b in self.ebullets:
                if self.my - 150 < b[1] < self.my + 10 and abs(b[0] + 3 - self.mx) < 44:
                    push += 1 if b[0] + 3 < self.mx else -1
                    if b[0] + 3 == self.mx:
                        push += self.m_side
            if push != 0:
                gx = self.mx + (100 if push > 0 else -100)

            k = min(1.0, dt * 6.0)      # mas lenta que el jugador: se nota que es una IA
            self.mx += (gx - self.mx) * k
            self.my += (gy - self.my) * k
            self.mx = max(36.0, min(ES_W - 36.0, self.mx))
            self.my = max(80.0, min(ES_H - 40.0, self.my))

            if self.over:
                return

            # disparo (usa el mismo nivel de arma que el jugador)
            if self.m_stun <= 0:
                self.m_fire -= dt
                if self.m_fire <= 0:
                    self.m_fire = 0.32 * (0.55 if self.rapid > 0 else 1.0)
                    if len(self.bullets) < ES_MAX_BULLETS - 4:
                        x = self.mx - 3
                        y = self.my - 38
                        if self.wl == 1:
                            self.bullets.append([x, y, 0])
                        elif self.wl == 2:
                            self.bullets.append([x - 10, y, 0])
                            self.bullets.append([x + 10, y, 0])
                        else:
                            self.bullets.append([x, y, 0])
                            self.bullets.append([x - 12, y + 6, -120])
                            self.bullets.append([x + 12, y + 6, 120])

            # si la tocan, se aturde un momento (no pierde nada)
            if self.m_inv <= 0:
                cx = self.mx - 6
                cy = self.my - 7
                hit = False
                for b in self.ebullets:
                    if es_overlap(cx, cy, 12, 14, b[0], b[1], 6, 15):
                        b[1] = ES_H + 100
                        hit = True
                for e in self.enemies:
                    w, h = ES_ESZ[e[4]]
                    if e[5] > 0 and es_overlap(cx, cy, 12, 14, e[7] + 8, e[1] + 8, w - 16, h - 16):
                        self.add_boom(e[7] + w / 2.0, e[1] + h / 2.0)
                        e[5] = 0
                        hit = True
                bs = self.boss
                if bs is not None and es_overlap(cx, cy, 12, 14, bs[0] - self.bbox(bs)[0], bs[1] + self.bbox(bs)[1],
                                                 self.bbox(bs)[2], self.bbox(bs)[3]):
                    hit = True
                if hit:
                    self.m_stun = 2.0
                    self.m_inv = 3.0
                    self.add_boom(self.mx, self.my)
                    self.add_float(self.mx - 20, self.my - 50, u"¡Ay!", "#ffffff")
                    self.spark(self.mx, self.my, 8, ["#ffffff", "#9bffb0"], spd=200, life=0.4)

        def drone_pos(self):
            a = self.dang
            c = 62 * math.cos(a)
            s = 14 * math.sin(a)
            return [(c, s - 4), (-c, -s - 4)]

        def cause_key(self):
            """(categoria, detalle) de lo que te esta derrotando ahora mismo."""
            hl = self.hz_last
            if hl is not None and self.elapsed - hl[1] < 1.2:
                return ("hz", hl[0])
            bs = self.boss
            if bs is not None and len(bs) > 6:
                return ("mini", ES_MINI[bs[6]][0])
            if bs is not None:
                return ("boss", u"")
            if self.phase == "bonus":
                return ("bonus", u"")
            return ("wave", u"")

        def finish(self, win):
            self.over = True
            self.victory = win
            self.over_t = 0.0
            self.combo = 0
            self.leaving = False
            self.leave_t = 0.0
            if not win:
                # donde fallamos (lo muestra la tarjeta de derrota)
                cat, det = self.cause_key()
                if cat == "hz":
                    self.fail_who = u"un peligro del nivel (" + det + u")"
                elif cat == "mini":
                    self.fail_who = u"el mini-jefe " + det
                elif cat == "boss":
                    self.fail_who = u"el jefe del nivel"
                elif cat == "bonus":
                    self.fail_who = u"las rocas del nivel bonus"
                else:
                    self.fail_who = u"la oleada de enemigos"
            renpy.music.stop(channel="es_music", fadeout=1.5)
            if win:
                if not self.practice:
                    self.score += 1000 + 300 * self.lives
                self.sfx("clear")
                self.spark(ES_W / 2.0, 150, 40, ES_CONFETTI, spd=420, life=1.6, size=5, grav=240)
                self.ring(ES_W / 2.0, 200, 1, 4.0, 0.8)
                head = self.T(u"¡VICTORIA!", 90, "#ffe066")
            else:
                self.sfx("gameover")
                head = self.T(u"GAME OVER", 84, "#ff6688")
            line = self.over_line(self.score)
            self.over_txt = [
                head,
                Text(line, size=40, color="#ffffff", outlines=[(2, "#000000", 0, 0)]),
                Text(u"Toca para continuar", size=32, color="#cccccc",
                     outlines=[(2, "#000000", 0, 0)]),
            ]

        # ---------- dibujo ----------
        def put(self, r, d, x, y, st, at):
            r.blit(renpy.render(d, ES_W, ES_H, st, at), (int(x), int(y)))

        def center(self, r, d, y, st, at):
            tr = renpy.render(d, ES_W, ES_H, st, at)
            tw, th = tr.get_size()
            r.blit(tr, (int((ES_W - tw) / 2), int(y)))

        def render(self, width, height, st, at):
            # si pasa mucho tiempo entre cuadros (app en segundo plano), pausa sola
            if (self.last_st is not None and not self.paused and not self.over
                    and st - self.last_st > 1.0):
                self.paused = True
                self.auto_paused = True
                renpy.music.set_pause(True, channel="es_music")
            if self.paused or self.last_st is None:
                dt = 0.0
            else:
                dt = min(st - self.last_st, 0.05)   # evita saltos tras pausas
            self.last_st = st
            if not self.paused:
                if self.resume_t > 0:
                    # cuenta atras tras reanudar: el juego espera, la nave sigue al dedo
                    self.resume_t -= dt
                    k = min(1.0, dt * 14.0)
                    self.px += (self.tx - self.px) * k
                    self.py += (self.ty - self.py) * k
                elif self.hitstop > 0:
                    self.hitstop -= dt     # congelado: corre el tiempo real, no el juego
                else:
                    if self.slowmo > 0:
                        self.slowmo -= dt
                        dt *= 0.4          # camara lenta breve
                    self.update(dt)

            # temblor de pantalla (solo el mundo, no el HUD)
            ox = oy = 0
            if self.shake > 0 and not self.paused and self.fx > 0:
                m = min(14.0, self.shake * 26.0)
                ox = random.uniform(-m, m)
                oy = random.uniform(-m, m)

            r = renpy.Render(ES_W, ES_H)
            put = self.put

            def putw(d, x, y):
                put(r, d, x + ox, y + oy, st, at)

            put(r, self.bgs[self.si], 0, 0, st, at)
            # nebulosa que se desplaza lento (dos copias para que no haya corte)
            put(r, self.i_neb[self.si], 0, self.neb_y, st, at)
            put(r, self.i_neb[self.si], 0, self.neb_y - ES_H, st, at)
            if self.planet is not None:
                pw, ph = ES_PLANET_SZ[self.si]
                putw(self.i_planet[self.si], self.planet[0] - pw / 2.0,
                     self.planet[1] - ph / 2.0)
            sm = self.star_mul
            if self.fx >= 1:
                for fr in self.far_rocks:
                    tf, zq = self.ztf(self.i_en[4], fr[4], 0.45, 20, 8)
                    putw(tf, fr[0] - 28 * zq, fr[1] - 28 * zq)
            for s in self.stars:
                if sm > 2.5:
                    h = min(520, int(s[2] * sm * 0.05))
                    putw(self.streak(h, s[3]), s[0], s[1] - h)
                putw(self.i_star[s[3]], s[0], s[1])
            if self.fx >= 1 and sm <= 2.5:
                dust_i = self.pimg("#9fb0ff", 2, 2)
                for d_ in self.dust:
                    putw(dust_i, d_[0], d_[1])
            if sm > 2.5:
                for L in self.wp_lines:
                    h = min(560, int(260 * min(sm, 14.0) * 0.09 * L[2]))
                    putw(self.streak(h, L[3] + 2), L[0], L[1] - h)
            if self.fx >= 1:
                # ambiente del nivel y rayos de la tormenta (detras de todo)
                for a in self.amb:
                    putw(self.pimg(a[6], a[7], a[8]), a[0], a[1])
                if self.bolt is not None and int(self.bolt[1] * 40) % 3 != 2:
                    putw(self.i_bolt[self.bolt[2]], self.bolt[0] - 80, 0)
                    if self.fx >= 2 and self.bolt[1] < 0.07:
                        put(r, self.bolt_fl, 0, 0, st, at)
            es_hz_draw(self, r, putw, st, at, 0)
            for p in self.powerups:
                if self.fx >= 1 and p[2] != 6:
                    z = 0.20 + 0.04 * (int(self.elapsed * 6 + p[0] * 0.02) % 3)
                    tf, zq = self.ztf(self.i_ring[ES_PU_RING[p[2]]], z, 0.85, 25, 8)
                    putw(tf, p[0] - 128 * zq, p[1] - 128 * zq)
                putw(self.i_pu[p[2]], p[0] - 18, p[1] - 18)
            if self.magnet > 0 and self.fx >= 1 and not self.over:
                mg_i = self.pimg("#c79bff", 3, 1)
                for p in self.powerups[:6]:
                    dx_ = self.px - p[0]
                    dy_ = self.py - p[1]
                    if math.hypot(dx_, dy_) < 380:
                        for k in range(4):
                            f_ = ((self.elapsed * 1.6 + k * 0.25) % 1.0)
                            putw(mg_i, p[0] + dx_ * f_, p[1] + dy_ * f_)
            if self.fx >= 1:
                gc = ES_BUL_GLOW.get(self.wl, "#6fd3ff")
                g_o = self.part_glow(gc, 16, 30, "50")
                g_t1 = self.part_glow(gc, 4, 12, "70")
                g_t2 = self.part_glow(gc, 2, 12, "38")
                for b in self.bullets:
                    putw(g_o, b[0] - 5, b[1] - 6)
                    if self.fx >= 2:
                        putw(g_t1, b[0] + 1, b[1] + 18)
                        putw(g_t2, b[0] + 2, b[1] + 30)
                    putw(self.i_bullet, b[0], b[1])
            else:
                for b in self.bullets:
                    putw(self.i_bullet, b[0], b[1])
            for b in self.ebullets:
                putw(self.i_ebullet, b[0], b[1])
            if self.fx >= 1:
                for e in self.enemies:
                    if e[4] == 2:      # kamikaze: rayas de velocidad
                        putw(self.streak(44, 4), e[7] + 20, e[1] - 40)
                        putw(self.streak(60, 4), e[7] + 38, e[1] - 56)
            for e in self.enemies:
                if self.fx >= 1 and self.hflash and id(e) in self.hflash:
                    putw(self.flash_img(ES_EN_NAMES[e[4]]), e[7], e[1])
                else:
                    putw(self.i_en[e[4]], e[7], e[1])
            # avisos de ataque: columnas rojas arriba antes de un muro o lluvia de balas
            for sh in self.shots:
                if int(sh[0] * 16) % 2 == 0:
                    for xm in sh[2]:
                        putw(self.tele_a, xm - 4, 0)
                        putw(self.tele_b, xm - 4, 0)
            es_hz_draw(self, r, putw, st, at, 1)

            bs = self.boss
            if bs is not None:
                fl = self.boss_flash > 0 and self.fx >= 1
                bdx, bdy = self.brec
                if len(bs) > 6:
                    putw(self.flash_img("mini%d" % bs[6]) if fl else self.i_mini[bs[6]],
                         bs[0] - 64 + bdx, bs[1] + bdy)
                else:
                    if fl:
                        bimg = self.flash_img("boss%d" % self.si)
                    elif self.ph2 and self.fx >= 1:
                        bimg = self.tint_img("boss%d" % self.si)
                    else:
                        bimg = self.i_boss[self.si]
                    putw(bimg, bs[0] - 80 + bdx, bs[1] + bdy)
                if self.bparts:
                    self.draw_parts(bs, putw)

            if not self.over and self.laser > 0 and (self.laser > 1 or int(self.laser * 10) % 2 == 0):
                putw(self.laser_o, self.px - 14, self.py - 30 - ES_H)
                putw(self.laser_i, self.px - 5, self.py - 30 - ES_H)

            # estela del motor y humo (detras de la nave)
            for p in self.parts_b:
                putw(self.pimg(p[6], p[8], min(3, int(4.0 * p[4] / p[5]))), p[0], p[1])

            # durante el salto la nave (y Monika) se desplazan y sale la llama
            sy = self.ship_dy
            sx = 0.0
            warping = (self.phase == "warp" and self.phase_t < self.WP_C) or self.arrive_t > 0
            if self.phase == "warp" and self.phase_t < self.WP_A:
                sx = random.uniform(-4.0, 4.0)
            if warping and not self.over:
                fl = int(self.elapsed * 30) % 2
                lvl = min(3, 1 + int(self.star_mul / 6.0))
                li = max(0, min(3, lvl - fl))
                putw(self.flame_o[li], self.px + sx - 7, self.py + 22 + sy)
                putw(self.flame_i[li], self.px + sx - 3, self.py + 22 + sy)
                if self.coop:
                    putw(self.flame_o[li], self.mx + sx - 7, self.my + 22 + sy)
                    putw(self.flame_i[li], self.mx + sx - 3, self.my + 22 + sy)
            if self.fx >= 2 and not self.over:
                for g_ in self.ghosts:
                    gi, gw_, gh_ = self.bank_img(self.i_player, g_[2])
                    gt, _z = self.ztf(gi, 1.0, 0.5 * (1.0 - g_[3] / 0.28), 20, 4)
                    putw(gt, g_[0] - gw_ / 2.0, g_[1] - gh_ / 2.0)
            if self.fx >= 1 and not warping and not self.over:
                ei = 0 if self.eng < 0.2 else (1 if self.eng < 0.5 else (2 if self.eng < 0.8 else 3))
                ei = min(3, ei + (1 if int(self.elapsed * 22) % 3 == 0 else 0))
                putw(self.eng_o[ei], self.px - 5, self.py + 22 + sy)
                putw(self.eng_i[ei], self.px - 2, self.py + 22 + sy)
                if self.coop:
                    mi_ = (1 if abs(self.mbank) > 0.4 else 0) + (1 if int(self.elapsed * 22) % 3 == 0 else 0)
                    putw(self.eng_o[mi_], self.mx - 5, self.my + 22 + sy)
                    putw(self.eng_i[mi_], self.mx - 2, self.my + 22 + sy)
            if not self.over and not (self.inv > 0 and int(self.inv * 12) % 2 == 0):
                bi, bw_, bh_ = self.bank_img(self.i_player, self.bank)
                putw(bi, self.px - bw_ / 2.0 + sx, self.py - bh_ / 2.0 + sy)
                if self.shield > 0 and (self.shield > 2 or int(self.shield * 8) % 2 == 0):
                    if self.fx >= 1:
                        zz = (1.0, 1.06, 1.0, 0.95)[int(self.elapsed * 7) % 4]
                        tf, zq = self.ztf(self.i_shield, zz, 1.0, 20, 4)
                        putw(tf, self.px - 42 * zq + sx, self.py - 42 * zq + sy)
                    else:
                        putw(self.i_shield, self.px - 42 + sx, self.py - 42 + sy)
            if self.sh_hit > 0 and self.fx >= 1 and not self.over:
                k_ = 1.0 - self.sh_hit / 0.35
                tf, zq = self.ztf(self.i_shield, 1.0 + 1.0 * k_, 1.0 - k_, 20, 8)
                putw(tf, self.px - 42 * zq + sx, self.py - 42 * zq + sy)
            if self.coop and not self.over:
                if not (self.m_inv > 0 and int(self.m_inv * 12) % 2 == 0):
                    mi, mw_, mh_ = self.bank_img(self.i_monika, self.mbank)
                    putw(mi, self.mx - mw_ / 2.0 + sx, self.my - mh_ / 2.0 + sy)
            if not self.over:
                # nucleo: lo unico que cuenta como golpe
                putw(self.core_o, self.px - 5 + sx, self.py - 5 + sy)
                putw(self.core_i, self.px - 3 + sx, self.py - 3 + sy)
            if not self.over and self.drones > 0 and (self.drones > 2 or int(self.drones * 8) % 2 == 0):
                for (dx, dy) in self.drone_pos():
                    putw(self.i_drone, self.px + dx - 12 + sx, self.py + dy - 12 + sy)

            # anillos de poder alrededor de la nave mientras dura cada efecto
            if self.fx >= 1 and not self.over and self.phase != "warp":
                rs = 0
                for (val, ci) in ((self.rapid, 1), (self.x2, 6), (self.magnet, 5),
                                  (self.drones, 4), (self.laser, 2), (self.slow, 0)):
                    if val > 0 and (val > 2 or int(val * 8) % 2 == 0):
                        z = 0.40 + 0.07 * rs + 0.02 * ((int(self.elapsed * 8) + rs) % 3)
                        tf, zq = self.ztf(self.i_ring[ci], z, 0.7, 25, 8)
                        putw(tf, self.px - 128 * zq + sx, self.py - 128 * zq + sy)
                        rs += 1
            for b in self.booms:
                f = min(3, int(b[2] / 0.08))
                putw(self.i_boom[f], b[0] - 36, b[1] - 36)
            # anillos de onda y particulas (delante)
            for rg in self.rings:
                k = rg[2] / rg[3]
                z = rg[4] * (1.0 - (1.0 - k) * (1.0 - k))
                tf, zq = self.ztf(self.i_ring[rg[5]], max(0.08, z), 1.0 - k, 10, 5)
                putw(tf, rg[0] - 128 * zq, rg[1] - 128 * zq)
            for p in self.parts:
                putw(self.pimg(p[6], p[8], min(3, int(4.0 * p[4] / p[5]))), p[0], p[1])

            # vinetas de color en los bordes: dano, fase 2, combo alto, ultima vida, jefe final
            if self.fx >= 1 and self.phase != "warp":
                vs = []
                if self.vig_hurt > 0:
                    vs.append((1, min(1.0, self.vig_hurt / 0.4)))
                if self.vig_ph2 > 0:
                    vs.append((1, min(1.0, self.vig_ph2) * (0.55 + 0.35 * math.sin(self.elapsed * 9.0))))
                if not self.over:
                    if self.combo >= 20:
                        vs.append((0, 0.5 + 0.2 * math.sin(self.elapsed * 7.0)))
                    elif self.combo >= 10:
                        vs.append((0, 0.28 + 0.1 * math.sin(self.elapsed * 4.0)))
                    if self.lives == 1:
                        vs.append((1, 0.12 + 0.55 * max(0.0, self.hb_pulse) / 0.4))
                if self.si == 9 and self.phase == "boss":
                    vs.append((2, 0.5))
                kf = 1.0 if self.fx >= 2 else 0.7
                for (vi, va) in vs:
                    vt = self.vigtf(vi, max(0.0, min(1.0, va * kf)))
                    if vt is not None:
                        put(r, vt, 0, 0, st, at)

            if self.fx >= 1 and self.boss is not None and len(self.boss) < 7:
                if self.ph2_t > 0:
                    put(r, self.black_s[min(3, int(self.ph2_t / 1.8 * 3 + 0.5))], 0, 0, st, at)
                elif self.ph2:
                    pl = int((0.5 + 0.5 * math.sin(self.elapsed * 3.0)) * 3.99)
                    pk = ("ph2bg", pl)
                    pd = self.part_cache.get(pk)
                    if pd is None:
                        pd = Solid("#ff1030%02x" % (0x12 + 0x08 * pl))
                        self.part_cache[pk] = pd
                    put(r, pd, 0, 0, st, at)
            es_hz_draw(self, r, putw, st, at, 2)
            if self.flash > 0 and self.fx > 0:
                put(r, self.flash_s[min(2, int(self.flash / 0.14))], 0, 0, st, at)

            # entrada del jefe: barras de cine y nombre
            if (self.fx >= 1 and self.phase == "boss" and self.boss is not None
                    and len(self.boss) < 7 and self.phase_t < 2.8 and not self.over):
                tb_ = self.phase_t
                kb_ = max(0.0, min(1.0, tb_ / 0.4, (2.8 - tb_) / 0.4))
                hb_ = int(64 * kb_ / 4) * 4
                if hb_ > 0:
                    lb_ = self.part_cache.get(("lb", hb_))
                    if lb_ is None:
                        lb_ = Solid("#000000", xysize=(ES_W, hb_))
                        self.part_cache[("lb", hb_)] = lb_
                    put(r, lb_, 0, 0, st, at)
                    put(r, lb_, 0, ES_H - hb_, st, at)
                if 0.5 <= tb_ < 2.6:
                    bn_ = self.part_cache.get(("bn", self.si))
                    if bn_ is None:
                        bn_ = Text(ES_BOSS_NAMES[self.si % len(ES_BOSS_NAMES)], size=58, color="#ffe680",
                                   bold=True, outlines=[(3, "#000000", 0, 0)])
                        self.part_cache[("bn", self.si)] = bn_
                    kn_ = (tb_ - 0.5) / 0.3
                    an_ = min(1.0, kn_, (2.6 - tb_) / 0.4)
                    tf, zq = self.ztf(bn_, 1.0 + 0.5 * max(0.0, 1.0 - kn_), an_, 10, 8)
                    self.center(r, tf, 340 - 30 * (zq - 1.0), st, at)

            # HUD (los textos solo se rehacen cuando cambian)
            key = (self.score, self.stage, self.wl)
            if key != self.hud_key:
                self.hud_key = key
                if self.endless:
                    s = u"Puntos: %d   Nivel: %d   Arma: %d" % key
                else:
                    s = u"Puntos: %d   Nivel: %d/%d   Arma: %d" % (key[0], key[1], self.nst, key[2])
                self.hud_txt = Text(s, size=30, color="#ffffff",
                                    outlines=[(2, "#000000", 0, 0)])
            put(r, self.hud_txt, 20, 12, st, at)
            for i in range(max(0, self.lives)):
                put(r, self.i_heart, 20 + i * 28, 52, st, at)

            k2 = tuple([int(v + 0.99) if v > 0 else 0 for v in
                        (self.rapid, self.x2, self.magnet, self.drones,
                         self.laser, self.slow)])
            if k2 != self.st_key:
                self.st_key = k2
                parts = [u"%s %ds" % (ES_STATUS_NAMES[i], v) for i, v in enumerate(k2) if v]
                self.st_txt = Text(u"   ".join(parts), size=26, color="#ffe680",
                                   outlines=[(2, "#000000", 0, 0)]) if parts else None
            if self.st_txt is not None:
                put(r, self.st_txt, 20, 92, st, at)

            ck = (self.combo, self.combo_mult()) if self.combo >= 3 else None
            if ck != self.cb_key:
                self.cb_key = ck
                if ck:
                    self.cb_txt = Text(u"Combo %d  (x%.1f)" % (ck[0], ck[1] / 10.0),
                                       size=28, color="#ffb347",
                                       outlines=[(2, "#000000", 0, 0)])
                else:
                    self.cb_txt = None
            if self.cb_txt is not None:
                put(r, self.cb_txt, 20, 124, st, at)
            if self.coop:
                put(r, self.t_msave_on if self.m_save > 0 else self.t_msave_off,
                    20, 160, st, at)

            # boton de bomba
            bx = 20 if self.lefty else 1160
            put(r, self.i_bombbtn, bx, 610, st, at)
            if self.bombs != self.bomb_key:
                self.bomb_key = self.bombs
                self.bomb_txt = Text(u"x%d" % self.bombs, size=34, color="#ffffff",
                                     outlines=[(3, "#000000", 0, 0)])
            put(r, self.bomb_txt, (bx + 105) if self.lefty else (bx - 40), 650, st, at)

            if bs is not None and self.bparts:
                up = len(self.parts_up())
                tot = len([p for p in self.bparts if p[6]])
                bkey = (up, tot)
                if bkey != self.bp_key:
                    self.bp_key = bkey
                    if up:
                        self.bp_txt = Text(u"Piezas del jefe: %d/%d" % bkey, size=30, color="#ffe680",
                                           outlines=[(2, "#000000", 0, 0)])
                    else:
                        self.bp_txt = Text(u"¡Destruye el núcleo!", size=30, color="#ff6688",
                                           outlines=[(2, "#000000", 0, 0)])
                self.center(r, self.bp_txt, 14, st, at)

            # salto: fundido a negro y pantalla de cambio de nivel
            if self.wp_black > 0.02:
                put(r, self.black_s[min(10, int(self.wp_black * 10 + 0.5))], 0, 0, st, at)
            if self.phase == "warp":
                tw = self.phase_t
                if tw < self.WP_C - 0.3 and int(tw * 5) % 2 == 0:
                    self.center(r, self.t_jump, 250, st, at)
                if tw >= self.WP_C and self.wp_title is not None:
                    a = min(1.0, (tw - self.WP_C) / 0.35)
                    self.center(r, self.wp_alpha(0, a), 240, st, at)
                    self.center(r, self.wp_alpha(1, a), 335, st, at)
                    prog = min(1.0, (tw - self.WP_C) / (self.WP_D - self.WP_C))
                    bw = int(prog * 24) * 20
                    if bw > 0:
                        bar = self.bar_cache.get(bw)
                        if bar is None:
                            bar = Solid("#ffe680", xysize=(bw, 4))
                            self.bar_cache[bw] = bar
                        self.center(r, bar, 410, st, at)

            # carteles
            if self.phase == "intro" and not self.over:
                self.center(r, self.banner[0], 240, st, at)
                self.center(r, self.banner[1], 335, st, at)
                if len(self.banner) > 3:
                    self.center(r, self.banner[2], 400, st, at)
                    self.center(r, self.banner[3], 442, st, at)
            elif self.phase == "bonus" and self.phase_t < 2.2 and not self.over:
                self.center(r, self.banner[0], 240, st, at)
                self.center(r, self.banner[1], 335, st, at)
            elif self.phase == "boss" and self.phase_t < 2.2 and int(self.phase_t * 4) % 2 == 0:
                self.center(r, self.t_warn, 260, st, at)
            elif self.phase == "clear" and not self.over:
                tc = self.phase_t
                if self.fx >= 1 and tc < 0.3:
                    tf, zq = self.ztf(self.t_clear, 1.0 + 1.2 * (1.0 - tc / 0.3),
                                      min(1.0, tc / 0.12), 10, 8)
                    self.center(r, tf, 230 - 35 * (zq - 1.0), st, at)
                else:
                    self.center(r, self.t_clear, 230, st, at)
                if self.rank_txt is not None:
                    if self.fx < 1 or tc >= 0.7:
                        self.center(r, self.rank_txt, 320, st, at)
                    elif tc >= 0.4:
                        # sello del rango: entra grande y encaja
                        tf, zq = self.ztf(self.rank_txt, 1.0 + 1.5 * (1.0 - (tc - 0.4) / 0.3),
                                          min(1.0, (tc - 0.4) / 0.1), 10, 8)
                        self.center(r, tf, 320 - 27 * (zq - 1.0), st, at)
            if (self.phase == "clear" and not self.over and self.rank_big is not None
                    and self.phase_t >= 0.55):
                kr_ = (self.phase_t - 0.55) / 0.3
                tf, zq = self.ztf(self.rank_big, 1.0 + 1.6 * max(0.0, 1.0 - kr_), min(1.0, kr_ * 2.0), 10, 8)
                self.center(r, tf, 395 - 100 * (zq - 1.0), st, at)
            if self.ph2_t > 0 and int(self.ph2_t * 5) % 2 == 0:
                self.center(r, self.t_ph2, 260, st, at)
            if self.mini_t > 0 and self.mini_txt is not None and int(self.mini_t * 5) % 2 == 0:
                self.center(r, self.mini_txt[0], 230, st, at)
                self.center(r, self.mini_txt[1], 320, st, at)

            for f in self.floats:
                put(r, f[3], f[0], f[1], st, at)
            for i, tt in enumerate(self.toasts[:2]):
                self.center(r, tt[0], 170 + 44 * i, st, at)

            if self.resume_t > 0 and not self.paused and not self.over:
                n = min(3, max(1, int(math.ceil(self.resume_t / 0.8))))
                self.center(r, self.t_count[n], 250, st, at)
                self.center(r, self.t_ready, 420, st, at)

            if self.say_t > 0 and self.say_txt is not None and not self.over:
                self.center(r, self.say_txt, 665, st, at)

            if self.paused and not self.quitting:
                self.center(r, self.t_pause, 300, st, at)
                if self.auto_paused:
                    self.center(r, self.t_resume, 410, st, at)

            if self.over and not self.victory:
                # derrota: la pantalla se va oscureciendo poco a poco
                k = min(7, int(min(1.0, self.over_t / 1.4) * 7 + 0.5))
                if k > 0:
                    put(r, self.black_s[k], 0, 0, st, at)
            if self.over and self.over_txt:
                self.center(r, self.over_txt[0], 200, st, at)
                t1 = self.over_txt[1]
                if self.fx >= 1 and self.over_t < 1.0 and self.score > 0:
                    # el marcador sube contando
                    stp = int(self.over_t * 20)
                    t1 = self.cu_cache.get(stp)
                    if t1 is None:
                        t1 = Text(self.over_line(self.score * stp // 20), size=40, color="#ffffff",
                                  outlines=[(2, "#000000", 0, 0)])
                        self.cu_cache[stp] = t1
                self.center(r, t1, 330, st, at)
                self.center(r, self.over_txt[2], 400, st, at)
            if self.over and self.leaving:
                # al tocar: fundido a negro total (tapa tambien el texto)
                k = min(10, int(min(1.0, self.leave_t / 0.8) * 10 + 0.5))
                put(r, self.black_s[k], 0, 0, st, at)

            if self.quitting:
                # al salir: fundido a negro de ~0.9 s (el texto tambien se apaga)
                if self.q_st0 is None:
                    self.q_st0 = st
                k = min(10, int(min(1.0, (st - self.q_st0) / 0.9) * 10 + 0.5))
                put(r, self.black_s[k], 0, 0, st, at)

            if not self.paused or self.quitting:
                renpy.redraw(self, self.rdt)
            return r

        # ---------- entrada (touch = mouse en Android) ----------
        def event(self, ev, x, y, st):
            if self.over:
                if self.over_t > 1.0 and ev.type == es_pygame.MOUSEBUTTONUP:
                    if self.victory:
                        return self.summary()
                    if not self.leaving:
                        # derrota: la pantalla se funde a negro y luego sigue la escena
                        self.leaving = True
                        self.leave_t = 0.0
                return None
            if self.paused:
                if (self.auto_paused and not self.confirm
                        and ev.type == es_pygame.MOUSEBUTTONUP):
                    self.toggle_pause()
                return None
            if ev.type == es_pygame.MOUSEBUTTONUP:
                self.down = False
            if self.phase == "warp":
                return None     # durante el salto no se controla la nave ni se lanzan bombas
            if ev.type == es_pygame.MOUSEBUTTONDOWN and getattr(ev, "button", 1) == 1:
                self.down = True
                self.anc_x = x
                self.anc_y = y
                self.anc_tx = self.tx
                self.anc_ty = self.ty
                bx = 20 if self.lefty else 1160
                if bx - 20 <= x <= bx + 120 and y > 590:
                    self.use_bomb()
                    self.down = False
                    return None
                if self.dtap:
                    if (st - self.last_tap < 0.32 and abs(x - self.tap_x) < 90
                            and abs(y - self.tap_y) < 90):
                        self.last_tap = -9.0
                        self.use_bomb()
                        return None
                    self.last_tap = st
                    self.tap_x = x
                    self.tap_y = y
            if ev.type in (es_pygame.MOUSEMOTION, es_pygame.MOUSEBUTTONDOWN):
                if self.relative:
                    # control relativo: la nave se mueve lo mismo que el dedo
                    if self.down:
                        self.tx = max(30, min(ES_W - 30, self.anc_tx + (x - self.anc_x)))
                        self.ty = max(60, min(ES_H - 40, self.anc_ty + (y - self.anc_y)))
                else:
                    # hz_ox/hz_oy: empuje de viento o gravedad (0 sin peligros)
                    self.tx = max(30, min(ES_W - 30, x + self.hz_ox))
                    self.ty = max(60, min(ES_H - 40, y - self.opt_off + self.hz_oy))   # nave sobre el dedo
            return None

        def visit(self):
            return self.all_images


screen encoders_shooter_screen(game):
    modal True
    zorder 200
    add Solid("#000000")
    add game
    key ES_BACK_KEY action Function(game.back_key)
    key "K_ESCAPE" action Function(game.back_key)
    if game.quitting:
        timer 1.0 action Function(game.finish_quit)
    elif not game.confirm:
        hbox:
            xalign 1.0
            yalign 0.0
            xoffset -15
            yoffset 10
            spacing 30
            textbutton (u"Reanudar" if game.paused else u"Pausa"):
                text_size 28
                text_color "#ffffff"
                text_hover_color "#ffcc66"
                action Function(game.toggle_pause)
            textbutton u"Salir":
                text_size 28
                text_color "#ffffff"
                text_hover_color "#ffcc66"
                action Function(game.ask_quit)
    else:
        frame:
            xalign 0.5
            yalign 0.5
            padding (50, 30)
            background Solid("#000000e0")
            vbox:
                spacing 18
                text u"¿Salir de la partida?" size 38 color "#ffffff" xalign 0.5
                text u"Se guardará tu puntaje actual." size 26 color "#cccccc" xalign 0.5
                hbox:
                    spacing 60
                    xalign 0.5
                    textbutton u"Sí, salir":
                        text_size 32
                        text_color "#ffffff"
                        text_hover_color "#ffcc66"
                        action Function(game.do_quit)
                    textbutton u"Seguir jugando":
                        text_size 32
                        text_color "#ffffff"
                        text_hover_color "#ffcc66"
                        action Function(game.cancel_quit)
