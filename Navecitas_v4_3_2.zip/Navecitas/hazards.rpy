# ---------------------------------------------------------------
#  Navecitas v4.0.1 - decoracion de nivel (antes "peligros por nivel")
#
#  Cada nivel conserva el ambiente de su fondo, pero AHORA ES SOLO
#  DECORACION: no hace dano, no empuja ni frena la nave, no avisa con
#  columnas y no tiene textos de peligro. Todo se dibuja DETRAS de
#  naves, balas y power-ups, con poca opacidad.
#
#   Nivel 1  Orbita Terrestre       restos de satelites a la deriva
#   Nivel 2  Cinturon de Asteroides meteoros lejanos
#   Nivel 3  Nebulosa Carmesi       corrientes de gas (rayas)
#   Nivel 4  Base Enemiga           lineas de escaner tenues
#   Nivel 5  Tormenta Solar         rayos (los dibuja shooter.rpy)
#   Nivel 6  Campo de Hielo         escarcha en los bordes
#   Nivel 7  Nucleo Alienigena      nubes de esporas
#   Nivel 8  Nave Nodriza           lineas de escaner tenues
#   Nivel 9  Agujero Negro          agujero y anillos de fondo
#   Nivel 10 Corazon del Vacio      agujero + meteoros y escaner
#
#  Se puede apagar en Ajustes > "Decoracion de nivel". Con efectos
#  visuales en "minimos" no se dibuja.
#  Compatible con Ren'Py 7 (Python 2) y Ren'Py 8 (Python 3).
# ---------------------------------------------------------------

init 11 python:
    import math
    import random

    # segundos entre elementos decorativos (los niveles sin entrada no generan)
    ES_HZ_IV = {0: 3.2, 1: 2.4, 3: 4.5, 6: 5.5, 7: 4.5, 9: 3.5}
    ES_HZ_MAX = 5          # maximo de elementos a la vez

    # ---------- utilidades ----------
    def es_hz_solid(g, col, w, h):
        key = (col, int(w), int(h))
        d = g.hz_cache.get(key)
        if d is None:
            d = Solid(col, xysize=(int(w), int(h)))
            g.hz_cache[key] = d
        return d

    def es_hz_init(g):
        """Se llama una vez al crear la partida (antes de reset)."""
        I = lambda n: renpy.displayable(ES_IMG + "es_" + n + ".png")
        g.hz_on = bool(getattr(persistent, "_es_hazards", True))
        g.hz_cache = {}
        g.i_hz_cloud = I("hz_cloud")     # 128x128
        g.i_hz_hole = I("hz_hole")       # 160x160
        g.i_hz_frost = Transform(I("hz_frost"), zoom=4.0)   # 320x180 -> pantalla
        g.all_images = g.all_images + [g.i_hz_cloud, g.i_hz_hole, g.i_hz_frost]
        g.hz = []
        g.hz_t = 2.0
        g.hz_w = {"dir": 1, "streaks": []}
        # los campos de abajo se conservan para que el resto del juego no cambie,
        # pero la decoracion nunca los modifica
        g.hz_ox = 0.0
        g.hz_oy = 0.0
        g.hz_last = None
        g.mv_k = 14.0
        g.fire_mul = 1.0
        g.hz_slide = False
        g.ivx = 0.0
        g.ivy = 0.0

    def es_hz_start(g):
        """Se llama al empezar cada nivel."""
        g.hz = []
        g.hz_t = 2.0
        g.hz_w = {"dir": random.choice((-1, 1)),
                  "streaks": [[random.uniform(0, ES_W), random.uniform(70, ES_H - 70),
                               random.uniform(0.6, 1.4)] for _i in range(14)]}

    def es_hz_clear(g):
        g.hz = []

    def es_hz_bomb(g):
        """La decoracion no reacciona a las bombas."""
        return

    def es_hz_slide(g, dt):
        """Ya no hay hielo resbaladizo (no se usa)."""
        return

    # ---------- creacion ----------
    def es_hz_spawn(g):
        si = g.si
        loops = (g.stage - 1) // ES_NST
        g.hz_t = ES_HZ_IV[si] * random.uniform(0.8, 1.3) * (1.0 + 0.15 * min(loops, 3))
        if len(g.hz) >= (3 if g.fx == 1 else ES_HZ_MAX):
            return
        kind = si
        if si == 9:
            kind = random.choice((1, 3, 7))
        if kind in (0, 1):
            fast = (kind == 1)
            g.hz.append({"k": "rock", "x": random.uniform(60, ES_W - 60), "y": -50.0,
                         "vy": random.uniform(250, 340) if fast else random.uniform(70, 120),
                         "z": random.uniform(0.55, 0.95), "fast": fast})
        elif kind == 6:
            g.hz.append({"k": "cloud", "x": random.uniform(100, ES_W - 100), "y": -70.0,
                         "vx": random.uniform(-14, 14), "vy": random.uniform(35, 55),
                         "r": random.choice((52, 62, 74)), "ph": random.uniform(0, 6.28)})
        elif kind == 3:
            g.hz.append({"k": "scan", "o": "v", "pos": random.choice((-30.0, ES_W + 30.0)),
                         "t": 0.0, "dur": 6.5})
        elif kind == 7:
            g.hz.append({"k": "scan", "o": "h", "pos": -30.0, "t": 0.0, "dur": 7.0})

    # ---------- actualizacion ----------
    def es_hz_update(g, dt):
        """Un llamado por cuadro. Solo mueve la decoracion: nunca toca la nave."""
        g.mv_k = 14.0
        g.fire_mul = 1.0
        g.hz_slide = False
        g.hz_ox = 0.0
        g.hz_oy = 0.0
        if (not g.hz_on or g.fx < 1 or g.over or g.arrive_t > 0
                or g.phase not in ("intro", "wave", "boss")):
            if g.hz:
                g.hz = []
            return
        si = g.si
        if si in ES_HZ_IV:
            g.hz_t -= dt
            if g.hz_t <= 0:
                es_hz_spawn(g)
        for h in g.hz:
            k = h["k"]
            if k == "rock":
                h["y"] += h["vy"] * dt
                if h["y"] > ES_H + 70:
                    h["dead"] = True
            elif k == "cloud":
                h["x"] += h["vx"] * dt
                h["y"] += h["vy"] * dt
                if h["y"] > ES_H + 90:
                    h["dead"] = True
            elif k == "scan":
                h["t"] += dt
                if h["t"] >= h["dur"]:
                    h["dead"] = True
        g.hz = [h for h in g.hz if not h.get("dead")]
        if si == 2:
            # corrientes de gas: rayas que cruzan despacio el fondo
            W = g.hz_w
            for s_ in W["streaks"]:
                s_[0] += W["dir"] * s_[2] * 260.0 * dt
                if s_[0] < -80:
                    s_[0] = ES_W + 20
                    s_[1] = random.uniform(70, ES_H - 70)
                elif s_[0] > ES_W + 80:
                    s_[0] = -20
                    s_[1] = random.uniform(70, ES_H - 70)

    # ---------- dibujo ----------
    def es_hz_draw(g, r, putw, st, at, layer):
        """layer 0: fondo (todo lo decorativo) / 1: nada / 2: escarcha del nivel 6."""
        si = g.si
        if not g.hz_on or g.fx < 1 or g.phase == "warp":
            return
        if layer == 0:
            if si in (8, 9):
                cx = ES_W / 2.0
                cy = ES_H / 2.0 - 10.0
                pulse = 1.0 + 0.05 * math.sin(g.elapsed * 3.0)
                tf, zq = g.ztf(g.i_hz_hole, pulse, 1.0, 40, 4)
                putw(tf, cx - 80 * zq, cy - 80 * zq)
                if g.fx >= 2 and g.arrive_t <= 0 and g.phase in ("wave", "boss"):
                    for i in (0, 1):
                        ph = (g.elapsed * 0.8 + i * 0.5) % 1.0      # anillos que se cierran
                        tf, zq = g.ztf(g.i_ring[5], 2.4 * (1.0 - ph) + 0.35, 0.15 + 0.6 * ph, 10, 5)
                        putw(tf, cx - 128 * zq, cy - 128 * zq)
            for h in g.hz:
                k = h["k"]
                if k == "cloud":
                    z = h["r"] * 2.0 / 128.0 * (1.0 + 0.05 * math.sin(g.elapsed * 2.0 + h["ph"]))
                    tf, zq = g.ztf(g.i_hz_cloud, z, 0.35, 20, 6)
                    putw(tf, h["x"] - 64 * zq, h["y"] - 64 * zq)
                elif k == "rock":
                    tf, zq = g.ztf(g.i_en[4], h["z"], 0.5, 10, 6)
                    putw(tf, h["x"] - 28 * zq, h["y"] - 28 * zq)
                    if h["fast"]:
                        putw(es_hz_solid(g, "#ffb34728", 3, 70), h["x"] - 1, h["y"] - 28 * zq - 70)
                elif k == "scan":
                    p = h["t"] / h["dur"]
                    a = min(1.0, p * 5.0, (1.0 - p) * 5.0)
                    col = "#ff9a3c22" if a > 0.5 else "#ff9a3c14"
                    if h["o"] == "h":
                        y = -20 + p * (ES_H + 40)
                        putw(es_hz_solid(g, col, ES_W, 3), 0, y)
                    else:
                        x = h["pos"] + (ES_W + 60 if h["pos"] < 0 else -(ES_W + 60)) * p
                        putw(es_hz_solid(g, col, 3, ES_H), x, 0)
            if si == 2:
                n = 14 if g.fx >= 2 else 6
                for s_ in g.hz_w["streaks"][:n]:
                    putw(es_hz_solid(g, "#ff8a9a28", 70, 3), s_[0], s_[1])
            return
        if layer == 2 and si == 5:
            g.put(r, g.i_hz_frost, 0, 0, st, at)
