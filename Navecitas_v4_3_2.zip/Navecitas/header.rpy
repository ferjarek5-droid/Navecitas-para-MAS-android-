init -990 python in mas_submod_utils:
    Submod(
        author="®J_24",
        name="Navecitas",
        description="Minijuego de naves con Monika. Ligero y pensado para Android.",
        version="4.3.2",
        settings_pane="navecitas_settings"
    )
